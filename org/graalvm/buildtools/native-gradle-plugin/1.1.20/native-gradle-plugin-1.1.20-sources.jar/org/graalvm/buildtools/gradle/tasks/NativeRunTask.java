/*
 * Copyright (c) 2021, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.graalvm.buildtools.gradle.tasks;

import org.gradle.api.DefaultTask;
import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.plugins.ApplicationPlugin;
import org.gradle.api.provider.ListProperty;
import org.gradle.api.provider.MapProperty;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.InputFile;
import org.gradle.api.tasks.Optional;
import org.gradle.api.tasks.PathSensitive;
import org.gradle.api.tasks.PathSensitivity;
import org.gradle.api.tasks.TaskAction;
import org.gradle.process.ExecOperations;
import org.gradle.work.DisableCachingByDefault;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Executes compiled native-image binaries for Gradle tasks and passes runtime arguments.
 * This implements §FS-native-tasks.2.
 */
@SuppressWarnings("unused")
@DisableCachingByDefault(because = "Executes a native application with external side effects")
public abstract class NativeRunTask extends DefaultTask {
    public static final String TASK_NAME = "nativeRun";

    @InputFile
    @PathSensitive(PathSensitivity.ABSOLUTE)
    public abstract RegularFileProperty getImage();

    @Input
    public abstract ListProperty<String> getRuntimeArgs();

    @Input
    @Optional
    public abstract MapProperty<String, String> getEnvironment();

    @Input
    public abstract ListProperty<String> getInternalRuntimeArgs();

    @Inject
    protected abstract ExecOperations getExecOperations();

    public NativeRunTask() {
        setDescription("Runs this project as a native-image application");
        setGroup(ApplicationPlugin.APPLICATION_GROUP);
    }

    @TaskAction
    public void exec() {
        getExecOperations().exec(spec -> {
            spec.setExecutable(getImage().get().getAsFile().getAbsolutePath());
            List<String> allRuntimeArgs = new ArrayList<>(getInternalRuntimeArgs().get());
            allRuntimeArgs.addAll(getRuntimeArgs().get());
            spec.args(allRuntimeArgs);
            if (getEnvironment().isPresent()) {
                Map<String, String> env = getEnvironment().get();
                for (Map.Entry<String, String> entry : env.entrySet()) {
                    spec.environment(entry.getKey(), entry.getValue());
                }
            }
        });
    }
}
