/*
 * Copyright (c) 2025, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.graalvm.buildtools.gradle;

import org.graalvm.buildtools.VersionInfo;
import org.graalvm.buildtools.agent.AgentConfiguration;
import org.graalvm.buildtools.agent.AgentMode;
import org.graalvm.buildtools.gradle.dsl.GraalVMExtension;
import org.graalvm.buildtools.gradle.dsl.GraalVMReachabilityMetadataRepositoryExtension;
import org.graalvm.buildtools.gradle.dsl.NativeImageOptions;
import org.graalvm.buildtools.gradle.dsl.NativeImageLayer;
import org.graalvm.buildtools.gradle.dsl.agent.AgentOptions;
import org.graalvm.buildtools.gradle.internal.AgentCommandLineProvider;
import org.graalvm.buildtools.gradle.internal.BaseNativeImageOptions;
import org.graalvm.buildtools.gradle.internal.DefaultGraalVmExtension;
import org.graalvm.buildtools.gradle.internal.DefaultTestBinaryConfig;
import org.graalvm.buildtools.gradle.internal.GraalVMLogger;
import org.graalvm.buildtools.gradle.internal.GraalVMReachabilityMetadataService;
import org.graalvm.buildtools.gradle.internal.GradleUtils;
import org.graalvm.buildtools.gradle.internal.NativeImageExecutableLocator;
import org.graalvm.buildtools.gradle.internal.NativeImageLayerRegistry;
import org.graalvm.buildtools.gradle.internal.agent.AgentConfigurationFactory;
import org.graalvm.buildtools.gradle.tasks.BuildNativeImageTask;
import org.graalvm.buildtools.gradle.tasks.CollectReachabilityMetadata;
import org.graalvm.buildtools.gradle.tasks.CreateLayerOptions;
import org.graalvm.buildtools.gradle.tasks.ValidateNativeImageLayerSelectionTask;
import org.graalvm.buildtools.gradle.tasks.GenerateAgentAccessFilter;
import org.graalvm.buildtools.gradle.tasks.GenerateDynamicAccessMetadata;
import org.graalvm.buildtools.gradle.tasks.GenerateNativeImageLauncherTask;
import org.graalvm.buildtools.gradle.tasks.GenerateResourcesConfigFile;
import org.graalvm.buildtools.gradle.tasks.ListLibrariesMissingMetadata;
import org.graalvm.buildtools.gradle.tasks.MetadataCopyTask;
import org.graalvm.buildtools.gradle.tasks.NativeRunTask;
import org.graalvm.buildtools.gradle.tasks.StageNativeImageLayerRuntimeFilesTask;
import org.graalvm.buildtools.gradle.tasks.actions.CleanupAgentFilesAction;
import org.graalvm.buildtools.gradle.tasks.actions.MergeAgentFilesAction;
import org.graalvm.buildtools.gradle.tasks.scanner.JarAnalyzerTransform;
import org.graalvm.buildtools.utils.JUnitPlatformNativeDependenciesHelper;
import org.graalvm.buildtools.utils.JUnitUtils;
import org.graalvm.buildtools.utils.NativeImageLayerArguments;
import org.graalvm.buildtools.utils.SharedConstants;
import org.graalvm.reachability.DirectoryConfiguration;
import org.graalvm.reachability.MissingMetadataCommandSupport;
import org.gradle.api.Action;
import org.gradle.api.NamedDomainObjectContainer;
import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.Task;
import org.gradle.api.artifacts.Configuration;
import org.gradle.api.artifacts.ConfigurationContainer;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.artifacts.ModuleVersionIdentifier;
import org.gradle.api.artifacts.component.ModuleComponentIdentifier;
import org.gradle.api.artifacts.result.DependencyResult;
import org.gradle.api.artifacts.result.ResolvedComponentResult;
import org.gradle.api.artifacts.result.ResolvedDependencyResult;
import org.gradle.api.attributes.Attribute;
import org.gradle.api.attributes.AttributeContainer;
import org.gradle.api.file.ArchiveOperations;
import org.gradle.api.file.ConfigurableFileCollection;
import org.gradle.api.file.Directory;
import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.file.DuplicatesStrategy;
import org.gradle.api.file.FileCollection;
import org.gradle.api.file.FileTree;
import org.gradle.api.file.FileSystemLocation;
import org.gradle.api.file.FileSystemOperations;
import org.gradle.api.file.RegularFile;
import org.gradle.api.distribution.DistributionContainer;
import org.gradle.api.logging.LogLevel;
import org.gradle.api.plugins.ExtensionAware;
import org.gradle.api.plugins.JavaApplication;
import org.gradle.api.plugins.JavaLibraryPlugin;
import org.gradle.api.plugins.JavaPlugin;
import org.gradle.api.plugins.JavaPluginExtension;
import org.gradle.api.provider.MapProperty;
import org.gradle.api.provider.Property;
import org.gradle.api.provider.Provider;
import org.gradle.api.provider.ProviderFactory;
import org.gradle.api.provider.SetProperty;
import org.gradle.api.tasks.Internal;
import org.gradle.api.tasks.OutputDirectory;
import org.gradle.api.tasks.SourceSet;
import org.gradle.api.tasks.SourceSetContainer;
import org.gradle.api.tasks.TaskCollection;
import org.gradle.api.tasks.TaskContainer;
import org.gradle.api.tasks.JavaExec;
import org.gradle.api.tasks.TaskProvider;
import org.gradle.api.tasks.bundling.AbstractArchiveTask;
import org.gradle.api.tasks.bundling.Jar;
import org.gradle.api.tasks.testing.Test;
import org.gradle.jvm.toolchain.JavaInstallationMetadata;
import org.gradle.jvm.toolchain.JavaLanguageVersion;
import org.gradle.jvm.toolchain.JavaLauncher;
import org.gradle.jvm.toolchain.JavaToolchainService;
import org.gradle.language.base.plugins.LifecycleBasePlugin;
import org.gradle.process.CommandLineArgumentProvider;
import org.gradle.process.ExecOperations;
import org.gradle.process.JavaForkOptions;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.io.File;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.graalvm.buildtools.gradle.internal.ConfigurationCacheSupport.serializableBiFunctionOf;
import static org.graalvm.buildtools.gradle.internal.ConfigurationCacheSupport.serializablePredicateOf;
import static org.graalvm.buildtools.gradle.internal.ConfigurationCacheSupport.serializableSupplierOf;
import static org.graalvm.buildtools.gradle.internal.ConfigurationCacheSupport.serializableTransformerOf;
import static org.graalvm.buildtools.gradle.internal.GradleUtils.transitiveProjectArtifacts;
import static org.graalvm.buildtools.gradle.internal.NativeImageExecutableLocator.graalvmHomeProvider;
import static org.graalvm.buildtools.utils.SharedConstants.AGENT_PROPERTY;
import static org.graalvm.buildtools.utils.SharedConstants.IS_WINDOWS;
import static org.graalvm.buildtools.utils.SharedConstants.METADATA_REPO_URL_TEMPLATE;

/**
 * Gradle plugin for GraalVM Native Image. §FS-plugin-model.
 */
public class NativeImagePlugin implements Plugin<Project> {
    public static final String NATIVE_COMPILE_TASK_NAME = "nativeCompile";
    public static final String NATIVE_TEST_COMPILE_TASK_NAME = "nativeTestCompile";
    public static final String NATIVE_TEST_TASK_NAME = "nativeTest";
    public static final String NATIVE_MAIN_EXTENSION = "main";
    public static final String NATIVE_TEST_EXTENSION = "test";

    public static final String DEPRECATED_NATIVE_BUILD_TASK = "nativeBuild";
    public static final String DEPRECATED_NATIVE_TEST_BUILD_TASK = "nativeTestBuild";

    public static final String CONFIG_REPO_LOGLEVEL = "org.graalvm.internal.gradle.configrepo.logging";
    public static final Attribute<Boolean> JAR_ANALYSIS_ATTRIBUTE = Attribute.of("jar-analysis", Boolean.class);

    private static final String NATIVE_CONFIGURATION_SERVICE_NAME = "nativeConfigurationService";
    private static final String JUNIT_PLATFORM_LISTENERS_UID_TRACKING_ENABLED = "junit.platform.listeners.uid.tracking.enabled";
    private static final String JUNIT_PLATFORM_LISTENERS_UID_TRACKING_OUTPUT_DIR = "junit.platform.listeners.uid.tracking.output.dir";
    private static final String JUNIT_PLATFORM_UNIQUE_IDS_RESOURCE_PATTERN = "junit-platform-unique-ids.*";
    private static final String REPOSITORY_COORDINATES = "org.graalvm.buildtools:graalvm-reachability-metadata:" + VersionInfo.NBT_VERSION + ":repository@zip";
    private static final String DEFAULT_URI = String.format(METADATA_REPO_URL_TEMPLATE, VersionInfo.METADATA_REPO_VERSION);

    // Compatibility Mode detection constants
    private static final String COMPATIBILITY_MODE_TOKEN = "-H:+CompatibilityMode";
    private static final String NATIVE_IMAGE_OPTIONS_ENV = "NATIVE_IMAGE_OPTIONS";

    private GraalVMLogger logger;
    private transient NativeImageLayerRegistry layerRegistry;

    // Exposed detection provider for test binaries (to be used by follow-up tasks)
    private Provider<Boolean> compatModeEnabled;

    @Inject
    public ArchiveOperations getArchiveOperations() {
        throw new UnsupportedOperationException();
    }

    @Inject
    public ExecOperations getExecOperations() {
        throw new UnsupportedOperationException();
    }

    @Inject
    public FileSystemOperations getFileOperations() {
        throw new UnsupportedOperationException();
    }


    @Override
    public void apply(@Nonnull Project project) {
        Provider<NativeImageService> nativeImageServiceProvider = NativeImageService.registerOn(project);

        logger = GraalVMLogger.of(project.getLogger());
        DefaultGraalVmExtension graalExtension = (DefaultGraalVmExtension) registerGraalVMExtension(project);
        graalExtension.getUseArgFile().convention(IS_WINDOWS);
        project.getPlugins()
            .withType(JavaPlugin.class, javaPlugin -> configureJavaProject(project, nativeImageServiceProvider, graalExtension));

        project.getPlugins().withType(JavaLibraryPlugin.class, javaLibraryPlugin -> graalExtension.getAgent().getDefaultMode().convention("conditional"));

        project.afterEvaluate(p -> {
            instrumentTasksWithAgent(project, graalExtension);
            for (NativeImageOptions options : graalExtension.getBinaries()) {
                if (options.getAgent().getOptions().get().size() > 0 || options.getAgent().getEnabled().isPresent()) {
                    logger.warn("The agent block in binary configuration '" + options.getName() + "' is deprecated.");
                    logger.warn("Such agent configuration has no effect and will become an error in the future.");
                }
            }
        });
    }

    private void instrumentTasksWithAgent(Project project, DefaultGraalVmExtension graalExtension) {
        Provider<String> agentMode = agentProperty(project, graalExtension.getAgent());
        if ("disabled".equals(agentMode.get())) {
            // Disabled agent mode must not instrument eligible JVM tasks. §gradle/FS-tracing-agent.3.
            logger.log("Not instrumenting tasks with native-image-agent because the agent is disabled.");
            return;
        }
        TaskProvider<GenerateAgentAccessFilter> defaultAccessFilter = project.getTasks().register(
                "generateAgentAccessFilter",
                GenerateAgentAccessFilter.class,
                task -> {
                    task.setDescription("Generates the native-image-agent built-in access filter.");
                    task.getOutputFile().convention(project.getLayout().getBuildDirectory()
                            .file("native/agent-config/access-filter.json"));
                });
        Predicate<? super Task> taskPredicate = graalExtension.getAgent().getTasksToInstrumentPredicate().getOrElse(serializablePredicateOf(t -> true));
        project.getTasks().configureEach(t -> {
            if (isTaskInstrumentableByAgent(t) && taskPredicate.test(t)) {
                configureAgent(project, agentMode, graalExtension, defaultAccessFilter, getExecOperations(), getFileOperations(), t, (JavaForkOptions) t);
            } else {
                String reason;
                if (isTaskInstrumentableByAgent(t)) {
                    reason = "Not instrumentable by agent as it does not extend JavaForkOptions.";
                } else {
                    reason = "Task does not match user predicate";
                }
                logger.log("Not instrumenting task with native-image-agent: " + t.getName() + ". Reason: " + reason);
            }
        });
    }

    private static boolean isTaskInstrumentableByAgent(Task task) {
        return task instanceof JavaForkOptions;
    }

    private static String deriveTaskName(String name, String prefix, String suffix) {
        if (NATIVE_MAIN_EXTENSION.equals(name)) {
            return prefix + suffix;
        }
        return prefix + capitalize(name) + suffix;
    }

    public static String compileTaskNameForBinary(String name) {
        return deriveTaskName(name, "native", "Compile");
    }

    private void configureJavaProject(Project project, Provider<NativeImageService> nativeImageServiceProvider, DefaultGraalVmExtension graalExtension) {
        logger.log("====================");
        logger.log("Initializing project: " + project.getName());
        logger.log("====================");

        // Add DSL extensions for building and testing
        NativeImageOptions mainOptions = createMainOptions(graalExtension, project);

        project.getPlugins().withId("application", p -> mainOptions.getMainClass().convention(
            Objects.requireNonNull(project.getExtensions().findByType(JavaApplication.class)).getMainClass()
        ));

        project.getPlugins().withId("java-library", p -> mainOptions.getSharedLibrary().convention(true));

        registerServiceProvider(project, nativeImageServiceProvider);

        // Configure artifact transform which allows extracting the package list from jars
        project.getDependencies().getAttributesSchema().attribute(JAR_ANALYSIS_ATTRIBUTE);
        project.getDependencies().getArtifactTypes().getByName("jar").getAttributes().attribute(JAR_ANALYSIS_ATTRIBUTE, false);
        project.getDependencies().registerTransform(JarAnalyzerTransform.class, t -> {
            t.getFrom().attribute(JAR_ANALYSIS_ATTRIBUTE, false);
            t.getTo().attribute(JAR_ANALYSIS_ATTRIBUTE, true);
        });

        // Register Native Image tasks
        TaskContainer tasks = project.getTasks();
        JavaPluginExtension javaConvention = project.getExtensions().getByType(JavaPluginExtension.class);
        configureAutomaticTaskCreation(project, graalExtension, tasks, javaConvention.getSourceSets());

        TaskProvider<BuildNativeImageTask> imageBuilder = tasks.named(NATIVE_COMPILE_TASK_NAME, BuildNativeImageTask.class);
        configureApplicationDistribution(project, mainOptions, imageBuilder,
            tasks.named("nativeLayerRuntimeFiles", StageNativeImageLayerRuntimeFilesTask.class), tasks);
        tasks.register(DEPRECATED_NATIVE_BUILD_TASK, t -> {
            t.setGroup(LifecycleBasePlugin.BUILD_GROUP);
            t.setDescription("Deprecated alias for nativeCompile.");
            t.dependsOn(imageBuilder);
            t.doFirst("Warn about deprecation", task -> task.getLogger().warn("Task " + DEPRECATED_NATIVE_BUILD_TASK + " is deprecated. Use " + NATIVE_COMPILE_TASK_NAME + " instead."));
        });

        graalExtension.registerTestBinary(NATIVE_TEST_EXTENSION, config -> {
            config.forTestTask(tasks.named("test", Test.class));
            config.usingSourceSet(GradleUtils.findSourceSet(project, SourceSet.TEST_SOURCE_SET_NAME));
        });

        project.getTasks().register("metadataCopy", MetadataCopyTask.class, task -> {
            task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
            task.setDescription("Copies and optionally merges metadata collected by agent-instrumented tasks into target directories.");
            task.getInputTaskNames().set(graalExtension.getAgent().getMetadataCopy().getInputTaskNames());
            task.getOutputDirectories().set(graalExtension.getAgent().getMetadataCopy().getOutputDirectories());
            task.getMergeWithExisting().set(graalExtension.getAgent().getMetadataCopy().getMergeWithExisting());
            task.getToolchainDetection().set(graalExtension.getToolchainDetection());
            JavaToolchainService toolchainService = project.getExtensions().findByType(JavaToolchainService.class);
            if (toolchainService != null) {
                Provider<JavaLauncher> toolchainLauncher = graalExtension.getToolchainDetection().flatMap(enabled -> {
                    if (enabled) {
                        return toolchainService.launcherFor(javaConvention.getToolchain());
                    }
                    return null;
                });
                task.setJavaLauncherConvention(toolchainLauncher);
            }
        });

        project.getTasks().register("collectReachabilityMetadata", CollectReachabilityMetadata.class, task -> {
            task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
            task.setDescription("Collects reachability metadata for the runtime classpath.");
            task.setClasspath(project.getConfigurations().getByName(JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME));
        });

        GraalVMReachabilityMetadataRepositoryExtension metadataRepositoryExtension = reachabilityExtensionOn(graalExtension);
        TaskCollection<CollectReachabilityMetadata> reachabilityMetadataCopyTasks = project.getTasks()
            .withType(CollectReachabilityMetadata.class);
        reachabilityMetadataCopyTasks.configureEach(task -> {
            Provider<GraalVMReachabilityMetadataService> reachabilityMetadataService = graalVMReachabilityMetadataService(
                project, metadataRepositoryExtension);
            task.getMetadataService().set(reachabilityMetadataService);
            task.usesService(reachabilityMetadataService);
            task.getUri().convention(task.getVersion().map(serializableTransformerOf(this::getReachabilityMetadataRepositoryUrlForVersion))
                .orElse(metadataRepositoryExtension.getUri()));
            task.getExcludedModules().convention(metadataRepositoryExtension.getExcludedModules());
            task.getModuleToConfigVersion().convention(metadataRepositoryExtension.getModuleToConfigVersion());
            task.getInto().convention(project.getLayout().getBuildDirectory().dir("native-reachability-metadata"));
        });
        project.getTasks().register("listLibrariesMissingMetadata", ListLibrariesMissingMetadata.class, task -> {
            task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
            task.setDescription("Lists direct runtime dependencies that do not have reachability metadata support");
            task.setClasspath(project.getConfigurations().getByName(JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME));
            Provider<GraalVMReachabilityMetadataService> reachabilityMetadataService = graalVMReachabilityMetadataService(
                project, metadataRepositoryExtension);
            task.getMetadataService().set(reachabilityMetadataService);
            task.usesService(reachabilityMetadataService);
            task.getMetadataRepositoryEnabled().convention(metadataRepositoryExtension.getEnabled());
            task.getMetadataRepositoryUri().convention(metadataRepositoryExtension.getUri().map(URI::toString));
            task.getCreateIssues().convention(project.getProviders().gradleProperty("createIssues").map(Boolean::parseBoolean).orElse(false));
            task.getGithubToken().convention(project.getProviders().gradleProperty("githubToken"));
            task.getTargetRepository().convention(
                project.getProviders().gradleProperty("targetRepository")
                    .orElse(MissingMetadataCommandSupport.DEFAULT_TARGET_REPOSITORY)
            );
            task.getGithubApiUrl().convention(
                project.getProviders().gradleProperty("githubApiUrl")
                    .orElse(MissingMetadataCommandSupport.DEFAULT_GITHUB_API_URL)
            );
            task.getProjectName().convention(project.getName());
            task.getExcludedModules().convention(metadataRepositoryExtension.getExcludedModules());
            task.getModuleToConfigVersion().convention(metadataRepositoryExtension.getModuleToConfigVersion());
            task.getReportFile().convention(
                project.getProviders().gradleProperty("reportFile")
                    .map(path -> project.getLayout().getProjectDirectory().file(path))
                    .orElse(project.getLayout().getBuildDirectory().file("reports/native/list-libraries-missing-metadata.json"))
            );
        });
    }

    private void configureAutomaticTaskCreation(Project project,
                                                DefaultGraalVmExtension graalExtension,
                                                TaskContainer tasks,
                                                SourceSetContainer sourceSets) {
        configureLayerTasks(project, graalExtension, tasks, sourceSets);
        graalExtension.getBinaries().configureEach(options -> {
            configureCustomApplicationBinary(project, options);
            String binaryName = options.getName();
            String compileTaskName = deriveTaskName(binaryName, "native", "Compile");
            if (NATIVE_MAIN_EXTENSION.equals(binaryName)) {
                compileTaskName = NATIVE_COMPILE_TASK_NAME;
            }
            TaskProvider<BuildNativeImageTask> imageBuilder = tasks.register(compileTaskName,
                BuildNativeImageTask.class, builder -> {
                    builder.setDescription("Builds a native executable for the " + options.getName() + " binary.");
                    builder.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                    builder.getOptions().convention(options);
                    builder.getUseArgFile().convention(graalExtension.getUseArgFile());
                    builder.getDisableToolchainDetection().convention(graalExtension.getToolchainDetection().map(enabled -> !enabled));

                    GraalVMReachabilityMetadataRepositoryExtension repoExt = reachabilityExtensionOn(graalExtension);
                    Provider<Boolean> repoEnabled =
                        repoExt.getEnabled().flatMap(serializableTransformerOf(enabled ->
                            enabled
                                ? repoExt.getUri()
                                    .map(serializableTransformerOf(obj -> true))
                                    .orElse(project.getProviders().provider(() -> false))
                                : project.getProviders().provider(() -> false)
                        ));
                    Provider<GraalVMReachabilityMetadataService> svc = graalVMReachabilityMetadataService(project, repoExt);
                    Provider<String> repoRootPath = svc.map(serializableTransformerOf(service ->
                        service.getRepositoryDirectory().map(p -> p.toAbsolutePath().toString()).orElse(null)
                    ));
                    builder.getMetadataRepositoryEnabled().set(repoEnabled);
                    builder.getMetadataRepositoryRootPath().set(repoRootPath);
                });
            configureLayerSelectionValidation(project, tasks, compileTaskName, options, imageBuilder);
            String stageTaskName = NATIVE_MAIN_EXTENSION.equals(binaryName)
                ? "nativeLayerRuntimeFiles"
                : deriveTaskName(binaryName, "native", "LayerRuntimeFiles");
            TaskProvider<StageNativeImageLayerRuntimeFilesTask> stagedRuntimeFiles = tasks.register(
                stageTaskName, StageNativeImageLayerRuntimeFilesTask.class, task -> {
                    task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                    task.setDescription("Stages runtime libraries for the " + options.getName() + " native binary.");
                    task.getLayerFiles().from(options.getLayerFiles());
                    task.getLayerDirectories().from(options.getLayerFiles().getElements()
                        .map(serializableTransformerOf(elements -> elements.stream()
                            .map(location -> location.getAsFile().getParentFile())
                            .toList())));
                    task.getDestinationDirectory().set(project.getLayout().getBuildDirectory()
                        .dir("native/layer-runtime-files/" + binaryName));
                });
            String runTaskName = deriveTaskName(binaryName, "native", "Run");
            var providers = project.getProviders();
            if (NATIVE_MAIN_EXTENSION.equals(binaryName)) {
                runTaskName = NativeRunTask.TASK_NAME;
            } else if (binaryName.toLowerCase(Locale.US).endsWith("test")) {
                runTaskName = "native" + capitalize(binaryName);
            }
            tasks.register(runTaskName, NativeRunTask.class, task -> {
                task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                task.setDescription("Runs the " + options.getName() + " native binary.");
                task.getImage().convention(imageBuilder.flatMap(BuildNativeImageTask::getOutputFile));
                task.getRuntimeArgs().convention(options.getRuntimeArgs());
                if (!options.getLayerFiles().isEmpty()) {
                    Provider<String> libsPath = options.getLayerFiles().getElements()
                        .map(serializableTransformerOf(elements -> elements.stream()
                            .map(location -> location.getAsFile().getParent())
                            .distinct()
                            .collect(Collectors.joining(File.pathSeparator))));
                    if (IS_WINDOWS) {
                        var pathVariable = providers.environmentVariable("PATH");
                        task.getEnvironment().put("PATH", pathVariable
                            .zip(libsPath, serializableBiFunctionOf((path, libs) -> path + File.pathSeparator + libs))
                            .orElse(libsPath));
                    } else {
                        String variable = System.getProperty("os.name", "").startsWith("Mac")
                            ? "DYLD_LIBRARY_PATH" : "LD_LIBRARY_PATH";
                        var ldLibraryPath = providers.environmentVariable(variable);
                        task.getEnvironment().put(variable, ldLibraryPath
                            .zip(libsPath, serializableBiFunctionOf((path, libs) -> path + File.pathSeparator + libs))
                            .orElse(libsPath));
                    }
                }
                task.getInternalRuntimeArgs().convention(
                    imageBuilder.zip(options.getPgoInstrument(), serializableBiFunctionOf((builder, pgo) -> {
                            if (Boolean.TRUE.equals(pgo)) {
                                File outputDir = builder.getOutputDirectory().get().getAsFile();
                                return Collections.singletonList("-XX:ProfilesDumpFile=" + new File(outputDir, "default.iprof").getAbsolutePath());
                            }
                            return Collections.emptyList();
                        })
                    ));
            });
            configureClasspathJarFor(tasks, options, imageBuilder);
            SourceSet sourceSet = "test".equals(binaryName) ? sourceSets.getByName(SourceSet.TEST_SOURCE_SET_NAME) : sourceSets.getByName(SourceSet.MAIN_SOURCE_SET_NAME);
            TaskProvider<GenerateResourcesConfigFile> generateResourcesConfig = registerResourcesConfigTask(
                graalExtension.getGeneratedResourcesDirectory(),
                options,
                tasks,
                transitiveProjectArtifacts(project, sourceSet.getRuntimeClasspathConfigurationName()),
                deriveTaskName(binaryName, "generate", "ResourcesConfigFile"));
            options.getConfigurationFileDirectories().from(generateResourcesConfig.map(serializableTransformerOf(t ->
                t.getOutputFile().map(serializableTransformerOf(f -> f.getAsFile().getParentFile()))
            )));
            TaskProvider<GenerateDynamicAccessMetadata> generateDynamicAccessMetadata = registerDynamicAccessMetadataTask(
                project.getConfigurations().getByName(JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME),
                graalVMReachabilityMetadataService(project, reachabilityExtensionOn(graalExtension)),
                project.getLayout().getBuildDirectory(),
                tasks,
                deriveTaskName(binaryName, "generate", "DynamicAccessMetadata"));
            imageBuilder.configure(buildImageTask -> {
                Provider<Boolean> emittingBuildReport =
                        buildImageTask.getOptions()
                                .flatMap(o -> o.getBuildArgs()
                                        .map(args -> args.stream()
                                                .anyMatch(NativeImagePlugin::emitsBuildReport)));
                options.getClasspath().from(
                        emittingBuildReport.flatMap(enabled ->
                                enabled
                                        ? generateDynamicAccessMetadata.flatMap(task ->
                                        task.getOutputJson().map(RegularFile::getAsFile))
                                        : buildImageTask.getProject().provider(Collections::emptyList))
                );
            });

            configureJvmReachabilityConfigurationDirectories(project, graalExtension, options, sourceSet);
            configureJvmReachabilityExcludeConfigArgs(project, graalExtension, options, sourceSet);
        });
    }

    private static void configureApplicationDistribution(Project project,
                                                         NativeImageOptions options,
                                                         TaskProvider<BuildNativeImageTask> imageBuilder,
                                                         TaskProvider<StageNativeImageLayerRuntimeFilesTask> stagedRuntimeFiles,
                                                         TaskContainer tasks) {
        project.afterEvaluate(ignored -> {
            if (options.getLayerFiles().isEmpty()) {
                return;
            }
            project.getPlugins().withId("application", applicationPlugin -> {
                TaskProvider<GenerateNativeImageLauncherTask> launcher = tasks.register(
                    "nativeDistributionLauncher", GenerateNativeImageLauncherTask.class, task -> {
                        task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                        task.setDescription("Generates the launcher for the layered native application distribution.");
                        task.getExecutableName().set(imageBuilder.flatMap(BuildNativeImageTask::getExecutableName));
                        task.getLauncherName().set(options.getImageName().map(name -> name + "-native"));
                        task.getOutputDirectory().set(project.getLayout().getBuildDirectory()
                            .dir("native/distribution-launcher"));
                    });
                DistributionContainer distributions = project.getExtensions().getByType(DistributionContainer.class);
                distributions.named("main", distribution -> {
                    distribution.getContents().from(imageBuilder.flatMap(BuildNativeImageTask::getOutputFile), spec -> {
                        spec.into("lib/native");
                    });
                    distribution.getContents().from(stagedRuntimeFiles.flatMap(
                        StageNativeImageLayerRuntimeFilesTask::getDestinationDirectory),
                        spec -> spec.into("lib/native-layers"));
                    distribution.getContents().from(launcher.flatMap(GenerateNativeImageLauncherTask::getOutputDirectory),
                        spec -> {
                            spec.into("bin");
                        });
                });
            });
        });
    }

    private void configureLayerTasks(Project project,
                                     GraalVMExtension graalExtension,
                                     TaskContainer tasks,
                                     SourceSetContainer sourceSets) {
        graalExtension.getLayers().configureEach(layer -> {
            String taskName = deriveTaskName(layer.getName(), "native", "Layer");
            NativeImageOptions layerOptions = project.getObjects().newInstance(
                BaseNativeImageOptions.class,
                "__layer_" + layer.getName(),
                project.getObjects(),
                project.getProviders(),
                project.getExtensions().findByType(JavaToolchainService.class),
                layerRegistry,
                "lib" + layer.getName()
            );
            CreateLayerOptions create = project.getObjects().newInstance(CreateLayerOptions.class);
            create.getLayerName().set(layer.getName());
            create.getAll().convention(layer.getContents().getAll());
            create.getModules().convention(layer.getContents().getModules());
            create.getPackages().convention(layer.getContents().getPackages());
            create.getJars().from(layer.getContents().getFiles());
            layerOptions.getLayerCreate().set(create);
            layerOptions.getLayerNames().addAll(layer.getUseLayerNames());
            layerOptions.getLayerFiles().from(layer.getUseLayerFiles());
            layerOptions.getBuildArgs().convention(layer.getBuildArgs());
            layerOptions.getVerbose().convention(layer.getVerbose());
            layer.getVerbose().convention(false);

            Configuration runtimeClasspath = project.getConfigurations()
                .getByName(JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME);
            create.getClasspath().from(layer.getContents().getAll()
                .flatMap(all -> Boolean.TRUE.equals(all)
                    ? layerOptions.resolvedArtifactsOf(runtimeClasspath)
                    : project.getProviders().provider(Collections::emptyList)));
            create.getClasspath().from(layer.getContents().getPackages()
                .flatMap(packages -> packages.isEmpty()
                    ? project.getProviders().provider(Collections::emptyList)
                    : project.getProviders().provider(() ->
                        sourceSets.getByName(SourceSet.MAIN_SOURCE_SET_NAME).getRuntimeClasspath())));
            create.getClasspath().from(layer.getInheritedCompatibilityClasspath());
            layer.getCompatibilityClasspath().from(create.getJars(), create.getClasspath());

            TaskProvider<BuildNativeImageTask> task = tasks.register(taskName, BuildNativeImageTask.class, builder -> {
                builder.setDescription("Builds the " + layer.getName() + " Native Image layer.");
                builder.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                builder.getOptions().set(layerOptions);
                builder.getUseArgFile().convention(graalExtension.getUseArgFile());
                builder.getOutputDirectory().set(project.getLayout().getBuildDirectory()
                    .dir("native/layers/" + layer.getName()));
                GraalVMReachabilityMetadataRepositoryExtension repoExt = reachabilityExtensionOn(graalExtension);
                Provider<Boolean> repoEnabled = repoExt.getEnabled().flatMap(serializableTransformerOf(enabled ->
                    enabled
                        ? repoExt.getUri().map(serializableTransformerOf(obj -> true))
                            .orElse(project.getProviders().provider(() -> false))
                        : project.getProviders().provider(() -> false)));
                Provider<GraalVMReachabilityMetadataService> svc = graalVMReachabilityMetadataService(project, repoExt);
                builder.getMetadataRepositoryEnabled().set(repoEnabled);
                builder.getMetadataRepositoryRootPath().set(svc.map(serializableTransformerOf(service ->
                    service.getRepositoryDirectory().map(path -> path.toAbsolutePath().toString()).orElse(null))));
            });
            configureLayerSelectionValidation(project, tasks, taskName, layerOptions, task);
            SourceSet mainSourceSet = sourceSets.getByName(SourceSet.MAIN_SOURCE_SET_NAME);
            configureJvmReachabilityConfigurationDirectories(project, graalExtension, layerOptions, mainSourceSet);
            configureJvmReachabilityExcludeConfigArgs(project, graalExtension, layerOptions, mainSourceSet);
            layer.getOutputFile().convention(task.flatMap(BuildNativeImageTask::getCreatedLayerFile));
        });
    }

    /**
     * Orders duplicate validation before all Native Image producers in a requested task graph.
     * §FS-plugin-model.2.
     */
    private static void configureLayerSelectionValidation(Project project,
                                                          TaskContainer tasks,
                                                          String consumerTaskName,
                                                          NativeImageOptions options,
                                                          TaskProvider<BuildNativeImageTask> consumer) {
        String validationTaskName = "validate" + capitalize(consumerTaskName) + "LayerSelection";
        TaskProvider<ValidateNativeImageLayerSelectionTask> validation = tasks.register(
            validationTaskName, ValidateNativeImageLayerSelectionTask.class, task -> {
                task.setGroup(LifecycleBasePlugin.BUILD_GROUP);
                task.setDescription("Validates Native Image layer selection for " + options.getName() + ".");
                task.getBinaryName().set(options.getName());
                task.getLayerNames().set(options.getLayerNames());
            });
        consumer.configure(task -> task.dependsOn(validation));
        tasks.withType(BuildNativeImageTask.class).configureEach(producer -> producer.mustRunAfter(validation));
    }

    private void configureCustomApplicationBinary(Project project, NativeImageOptions options) {
        ConfigurationContainer configurations = project.getConfigurations();
        String binaryName = options.getName();
        if (configurations.findByName(imageClasspathConfigurationNameFor(binaryName)) != null) {
            return;
        }
        // Custom application binaries share the main runtime classpath and option model. §FS-plugin-model.4
        createNativeConfigurations(project, binaryName, JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME);
        setupExtensionConfigExcludes(options, configurations);
        Configuration imageClasspath = configurations.getByName(imageClasspathConfigurationNameFor(binaryName));
        options.getClasspath().from(project.provider(() -> createsLayer(options) ? Collections.emptyList() : Collections.singletonList(imageClasspath)));
    }

    private static boolean createsLayer(NativeImageOptions options) {
        return options.getLayerCreate().isPresent();
    }

    private static boolean emitsBuildReport(String buildArg) {
        return buildArg.startsWith("--emit build-report") || buildArg.startsWith("-H:+BuildReport");
    }

    private void configureJvmReachabilityConfigurationDirectories(Project project,
                                                                  GraalVMExtension graalExtension,
                                                                  NativeImageOptions options,
                                                                  SourceSet sourceSet) {
        options.getConfigurationFileDirectories().from(
            graalVMReachabilityQueryForConfigDirectories(project,
                graalExtension,
                sourceSet,
                configuration -> true)
        );
    }

    private static File getConfigurationDirectory(DirectoryConfiguration configuration) {
        return configuration.getDirectory().toAbsolutePath().toFile();
    }

    private Provider<List<File>> graalVMReachabilityQueryForConfigDirectories(Project project, GraalVMExtension graalExtension,
                                                                              SourceSet sourceSet, Predicate<DirectoryConfiguration> filter) {
        GraalVMReachabilityMetadataRepositoryExtension extension = reachabilityExtensionOn(graalExtension);
        Provider<GraalVMReachabilityMetadataService> metadataServiceProvider = graalVMReachabilityMetadataService(project, extension);
        Provider<ResolvedComponentResult> rootComponent = project.getConfigurations()
            .getByName(sourceSet.getRuntimeClasspathConfigurationName())
            .getIncoming()
            .getResolutionResult()
            .getRootComponent();
        SetProperty<String> excludedModulesProperty = extension.getExcludedModules();
        MapProperty<String, String> moduleToConfigVersion = extension.getModuleToConfigVersion();
        Property<URI> uri = extension.getUri();
        ProviderFactory providers = project.getProviders();
        return extension.getEnabled().flatMap(serializableTransformerOf(enabled -> {
            if (Boolean.TRUE.equals(enabled) && uri.isPresent()) {
                Set<String> excludedModules = excludedModulesProperty.getOrElse(Collections.emptySet());
                Map<String, String> forcedVersions = moduleToConfigVersion.getOrElse(Collections.emptyMap());
                return metadataServiceProvider.map(serializableTransformerOf(service -> {
                    Set<ResolvedComponentResult> components = findAllComponentsFrom(rootComponent.get());
                    // Native compilation consumes the same graph-aware selection as collection.
                    // §common/FS-common-libraries.5.1 §FS-resources-and-metadata.3.
                    return service.findConfigurationsForModules(excludedModules, forcedVersions,
                            components.stream().map(ResolvedComponentResult::getModuleVersion).collect(Collectors.toList()))
                        .stream()
                        .filter(filter)
                        .map(NativeImagePlugin::getConfigurationDirectory)
                        .collect(Collectors.<File>toList());
                }));
            }
            return providers.provider(Collections::emptyList);
        }));
    }

    private Provider<Map<String, List<String>>> graalVMReachabilityQueryForExcludeList(Project project, GraalVMExtension graalExtension,
                                                                                       SourceSet sourceSet, Predicate<DirectoryConfiguration> filter) {
        GraalVMReachabilityMetadataRepositoryExtension extension = reachabilityExtensionOn(graalExtension);
        Provider<GraalVMReachabilityMetadataService> metadataServiceProvider = graalVMReachabilityMetadataService(project, extension);
        Provider<ResolvedComponentResult> rootComponent = project.getConfigurations()
            .getByName(sourceSet.getRuntimeClasspathConfigurationName())
            .getIncoming()
            .getResolutionResult()
            .getRootComponent();
        SetProperty<String> excludedModulesProperty = extension.getExcludedModules();
        MapProperty<String, String> moduleToConfigVersion = extension.getModuleToConfigVersion();
        Property<URI> uri = extension.getUri();
        ProviderFactory providers = project.getProviders();
        return extension.getEnabled().flatMap(serializableTransformerOf(enabled -> {
            if (Boolean.TRUE.equals(enabled) && uri.isPresent()) {
                Set<String> excludedModules = excludedModulesProperty.getOrElse(Collections.emptySet());
                Map<String, String> forcedVersions = moduleToConfigVersion.getOrElse(Collections.emptyMap());
                return metadataServiceProvider.map(serializableTransformerOf(service -> {
                    Set<ResolvedComponentResult> components = findAllComponentsFrom(rootComponent.get());
                    Map<String, ModuleVersionIdentifier> modulesByCoordinates = components.stream()
                            .map(ResolvedComponentResult::getModuleVersion)
                            .collect(Collectors.toMap(module -> module.getGroup() + ":" + module.getName(), module -> module, (left, right) -> left));
                    // Build exclusions from the complete graph-aware selection. §common/FS-common-libraries.5.1 §FS-resources-and-metadata.3.
                    return service.findConfigurationsForModules(excludedModules, forcedVersions, modulesByCoordinates.values())
                        .stream()
                        .filter(filter)
                        .map(configuration -> modulesByCoordinates.get(configuration.getGroupId() + ":" + configuration.getArtifactId()))
                        .filter(Objects::nonNull)
                        // Override exclusions belong to the directly resolved owner, never its requester. §FS-resources-and-metadata.3.
                        .map(NativeImagePlugin::getExclusionConfig)
                        .collect(Collectors.toMap(ExcludeEntry::getGav, ExcludeEntry::getExcludes, (left, right) -> left));
                }));
            }
            return providers.provider(Collections::emptyMap);
        }));
    }

    private static Set<ResolvedComponentResult> findAllComponentsFrom(ResolvedComponentResult resolvedComponentResult) {
        Set<ResolvedComponentResult> all = new LinkedHashSet<>();
        findAllComponentsFrom(resolvedComponentResult, all);
        return Collections.unmodifiableSet(all);
    }

    private static void findAllComponentsFrom(ResolvedComponentResult resolvedComponentResult, Set<ResolvedComponentResult> all) {
        if (all.add(resolvedComponentResult)) {
            Set<? extends DependencyResult> dependencies = resolvedComponentResult.getDependencies();
            for (DependencyResult dependencyResult : dependencies) {
                if (dependencyResult instanceof ResolvedDependencyResult) {
                    findAllComponentsFrom(((ResolvedDependencyResult) dependencyResult).getSelected(), all);
                }
            }
        }
    }

    private Provider<GraalVMReachabilityMetadataService> graalVMReachabilityMetadataService(Project project,
                                                                                            GraalVMReachabilityMetadataRepositoryExtension repositoryExtension) {
        // Keep metadata repository service parameters project-local. §FS-resources-and-metadata.3.
        return project.getGradle()
            .getSharedServices()
            .registerIfAbsent(NATIVE_CONFIGURATION_SERVICE_NAME + project.getPath(), GraalVMReachabilityMetadataService.class, spec -> {
                LogLevel logLevel = determineLogLevel();
                spec.getMaxParallelUsages().set(1);
                spec.getParameters().getLogLevel().set(logLevel);
                spec.getParameters().getEnabled().set(repositoryExtension.getEnabled());
                spec.getParameters().getUri().set(repositoryExtension.getUri().map(serializableTransformerOf(configuredUri -> computeMetadataRepositoryUri(project, repositoryExtension, m -> logFallbackToDefaultUri(m, logger)))));
                spec.getParameters().getRepositoryDescription().set(
                    repositoryExtension.getUri().zip(repositoryExtension.getVersion(),
                        serializableBiFunctionOf(NativeImagePlugin::describeSelectedMetadataRepository)));
                spec.getParameters().getCacheDir().set(
                    new File(project.getGradle().getGradleUserHomeDir(), "native-build-tools/repositories"));
                spec.getParameters().getBackoffMaxRetries().convention(
                    GradleUtils.intProperty(project.getProviders(), "exponential.backoff.max.retries", 3)
                );
                spec.getParameters().getInitialBackoffMillis().convention(
                    GradleUtils.intProperty(project.getProviders(), "exponential.backoff.initial.delay", 100)
                );
            });
    }

    private static void logFallbackToDefaultUri(URI defaultUri, GraalVMLogger logger) {
        logger.warn("Unable to find the GraalVM reachability metadata repository in Maven repository. " +
                    "Falling back to the default repository at " + defaultUri);
    }

    static String describeSelectedMetadataRepository(URI configuredUri, String version) {
        if (version != null) {
            try {
                URI versionUri = new URI(String.format(METADATA_REPO_URL_TEMPLATE, version));
                if (versionUri.equals(configuredUri)) {
                    return "version " + version;
                }
            } catch (URISyntaxException e) {
                throw new RuntimeException("Unable to convert repository version to URI", e);
            }
        }
        return "from " + configuredUri.toASCIIString();
    }

    static URI computeMetadataRepositoryUri(Project project,
                                            GraalVMReachabilityMetadataRepositoryExtension repositoryExtension,
                                            Consumer<? super URI> onFallback) {
        URI configuredUri = repositoryExtension.getUri().getOrNull();
        URI githubReleaseUri;
        URI defaultUri;
        try {
            defaultUri = new URI(DEFAULT_URI);
            githubReleaseUri = new URI(String.format(METADATA_REPO_URL_TEMPLATE, repositoryExtension.getVersion().get()));
        } catch (URISyntaxException e) {
            throw new RuntimeException("Unable to convert repository path to URI", e);
        }
        if (defaultUri.equals(configuredUri)) {
            // The user didn't configure any custom URI or repo version, so we're going to
            // use the Maven artifact instead. §FS-resources-and-metadata.3.
            Configuration configuration = project.getConfigurations().detachedConfiguration();
            Dependency e = project.getDependencies().create(REPOSITORY_COORDINATES);
            configuration.getDependencies().add(e);
            Set<File> files = configuration.getIncoming()
                .artifactView(view -> view.setLenient(true))
                .getFiles()
                .getFiles();
            if (files.size() == 1) {
                return files.iterator().next().toURI();
            } else {
                onFallback.accept(githubReleaseUri);
            }
        }
        return configuredUri;
    }

    private void configureJvmReachabilityExcludeConfigArgs(Project project, GraalVMExtension graalExtension, NativeImageOptions options, SourceSet sourceSet) {
        options.getExcludeConfig().putAll(
            graalVMReachabilityQueryForExcludeList(project,
                graalExtension,
                sourceSet,
                DirectoryConfiguration::isOverride)
        );
        GraalVMReachabilityMetadataRepositoryExtension repositoryExtension = reachabilityExtensionOn(graalExtension);
        graalVMReachabilityMetadataService(project, repositoryExtension);
    }

    private static ExcludeEntry getExclusionConfig(ModuleVersionIdentifier moduleVersion) {
        String gav = moduleVersion.getGroup() + ":" + moduleVersion.getName() + ":" + moduleVersion.getVersion();
        return new ExcludeEntry(gav, Arrays.asList("^/META-INF/native-image/.*"));
    }

    private static LogLevel determineLogLevel() {
        LogLevel logLevel = LogLevel.DEBUG;
        String loggingProperty = System.getProperty(CONFIG_REPO_LOGLEVEL);
        if (loggingProperty != null) {
            logLevel = LogLevel.valueOf(loggingProperty.toUpperCase(Locale.US));
        }
        return logLevel;
    }

    private static GraalVMReachabilityMetadataRepositoryExtension reachabilityExtensionOn(GraalVMExtension graalExtension) {
        return ((ExtensionAware) graalExtension).getExtensions().getByType(GraalVMReachabilityMetadataRepositoryExtension.class);
    }

    private void configureClasspathJarFor(TaskContainer tasks, NativeImageOptions options, TaskProvider<BuildNativeImageTask> imageBuilder) {
        String baseName = imageBuilder.getName();
        TaskProvider<Jar> classpathJar = tasks.register(baseName + "ClasspathJar", Jar.class, jar -> {
            jar.setDescription("Builds a pathing JAR for the " + options.getName() + " native binary classpath.");
            jar.from(
                options.getClasspath()
                    .getElements()
                    .map(elems -> elems.stream()
                        .map(e -> {
                            if (isJar(e)) {
                                return getArchiveOperations().zipTree(e);
                            }
                            return e;
                        })
                        .collect(Collectors.toList()))
            );
            jar.setDuplicatesStrategy(DuplicatesStrategy.WARN);
            jar.getArchiveBaseName().set(baseName.toLowerCase(Locale.ENGLISH) + "-classpath");
        });
        imageBuilder.configure(nit -> {
            if (options.getUseFatJar().get()) {
                nit.getClasspathJar().set(classpathJar.flatMap(AbstractArchiveTask::getArchiveFile));
            }
        });
    }

    private static boolean isJar(FileSystemLocation location) {
        return location.getAsFile().getName().toLowerCase(Locale.US).endsWith(".jar");
    }

    private GraalVMExtension registerGraalVMExtension(Project project) {
        layerRegistry = new NativeImageLayerRegistry(project.getObjects());
        NamedDomainObjectContainer<NativeImageLayer> layers = project.getObjects()
            .domainObjectContainer(NativeImageLayer.class, name -> {
                NativeImageLayerArguments.validateLayerName(name);
                NativeImageLayer layer = project.getObjects().newInstance(
                    NativeImageLayer.class, name, project.getObjects(), project, layerRegistry);
                layerRegistry.register(layer);
                return layer;
            });
        NamedDomainObjectContainer<NativeImageOptions> nativeImages = project.getObjects()
            .domainObjectContainer(NativeImageOptions.class, name ->
                project.getObjects().newInstance(BaseNativeImageOptions.class,
                    name,
                    project.getObjects(),
                    project.getProviders(),
                    project.getExtensions().findByType(JavaToolchainService.class),
                    layerRegistry,
                    project.getName())
            );
        GraalVMExtension graalvmNative = project.getExtensions().create(GraalVMExtension.class, "graalvmNative",
            DefaultGraalVmExtension.class, nativeImages, layers, this, project);
        graalvmNative.getGeneratedResourcesDirectory().set(project.getLayout()
            .getBuildDirectory()
            .dir("native/generated/"));
        configureNativeConfigurationRepo((ExtensionAware) graalvmNative);
        return graalvmNative;
    }

    private void configureNativeConfigurationRepo(ExtensionAware graalvmNative) {
        GraalVMReachabilityMetadataRepositoryExtension configurationRepository = graalvmNative.getExtensions().create("metadataRepository", GraalVMReachabilityMetadataRepositoryExtension.class);
        // Defaults stay enabled and pinnable through version or URI. §FS-resources-and-metadata.3.
        configurationRepository.getEnabled().convention(true);
        configurationRepository.getVersion().convention(VersionInfo.METADATA_REPO_VERSION);
        configurationRepository.getUri().convention(configurationRepository.getVersion().map(serializableTransformerOf(this::getReachabilityMetadataRepositoryUrlForVersion)));
        configurationRepository.getExcludedModules().convention(Collections.emptySet());
        configurationRepository.getModuleToConfigVersion().convention(Collections.emptyMap());
    }

    private URI getReachabilityMetadataRepositoryUrlForVersion(String version) {
        try {
            return new URI(String.format(METADATA_REPO_URL_TEMPLATE, version));
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private TaskProvider<GenerateResourcesConfigFile> registerResourcesConfigTask(Provider<Directory> generatedDir,
                                                                                  NativeImageOptions options,
                                                                                  TaskContainer tasks,
                                                                                  FileCollection transitiveProjectArtifacts,
                                                                                  String name) {
        return tasks.register(name, GenerateResourcesConfigFile.class, task -> {
            task.setDescription("Scans resources and generates a resource-config.json file for the " + options.getName() + " binary.");
            task.getOptions().convention(options.getResources());
            task.getClasspath().from(options.getClasspath());
            task.getTransitiveProjectArtifacts().from(transitiveProjectArtifacts);
            task.getOutputFile().convention(generatedDir.map(d -> d.file(name + "/resource-config.json")));
        });
    }

    private TaskProvider<GenerateDynamicAccessMetadata> registerDynamicAccessMetadataTask(Configuration classpathConfiguration,
                                                                                          Provider<GraalVMReachabilityMetadataService> metadataService,
                                                                                          DirectoryProperty buildDir,
                                                                                          TaskContainer tasks,
                                                                                          String name) {
        return tasks.register(name, GenerateDynamicAccessMetadata.class, task -> {
            task.setClasspath(classpathConfiguration);
            task.getMetadataService().set(metadataService);
            task.getOutputJson().set(buildDir.dir("generated").map(dir -> dir.file("dynamic-access-metadata.json")));
        });
    }

    public void registerTestBinary(Project project,
                                   DefaultGraalVmExtension graalExtension,
                                   DefaultTestBinaryConfig config) {
        NativeImageOptions mainOptions = graalExtension.getBinaries().getByName(NATIVE_MAIN_EXTENSION);
        String name = config.getName();
        boolean isPrimaryTest = "test".equals(name);
        TaskContainer tasks = project.getTasks();

        // Testing part begins here. -------------------------------------------

        DirectoryProperty testResultsDir = GradleUtils.getJavaPluginConvention(project).getTestResultsDir();
        DirectoryProperty testListDirectory = project.getObjects().directoryProperty();

        // Add DSL extension for testing
        NativeImageOptions testOptions = createTestOptions(graalExtension, name, project, mainOptions, config.getSourceSet());

        // Compute and expose the Compatibility Mode detection provider for test binary
        this.compatModeEnabled = computeCompatibilityModeEnabledProvider(project, testOptions);

        // Unified once-per-build log at configuration time if Compatibility Mode is enabled
        project.afterEvaluate(p -> {
            if (compatModeEnabled().getOrElse(false)) {
                logger.logOnce("Compatibility Mode detected (-H:+CompatibilityMode); The native test image will be built using the original JUnit ConsoleLauncher.");
            }
        });

        // Wire main class based on Compatibility Mode, mirroring Maven plugin behavior.
        testOptions.getMainClass().convention(compatModeEnabled().map(c -> c
                ? "org.junit.platform.console.ConsoleLauncher"
                : "org.graalvm.junit.platform.NativeImageJUnitLauncher"));

        // Add the JUnit Platform Feature flag and exclude JUnit class init files only when NOT in Compatibility Mode.
        final String junitPlatformFeatureFlag = "--features=org.graalvm.junit.platform.JUnitPlatformFeature";
        project.afterEvaluate(p -> {
            boolean compat = compatModeEnabled().getOrElse(false);
            if (!compat) {
                List<String> current = testOptions.getBuildArgs().getOrElse(Collections.emptyList());
                if (!current.contains(junitPlatformFeatureFlag)) {
                    testOptions.getBuildArgs().add(junitPlatformFeatureFlag);
                }
                /* in version 5.12.0 JUnit added initialize-at-build-time properties files which we need to exclude */
                testOptions.getBuildArgs().addAll(JUnitUtils.excludeJUnitClassInitializationFiles());
            }
        });
        // Add XML output dir only in regular mode (not in Compatibility Mode)
        Provider<String> xmlOutputDir = project.getLayout().getBuildDirectory()
                .dir("test-results/" + name + "-native")
                .map(d -> d.getAsFile().getAbsolutePath());
        testOptions.getRuntimeArgs().addAll(
                compatModeEnabled().zip(xmlOutputDir, serializableBiFunctionOf((compat, dir) ->
                        compat ? Collections.emptyList() : Arrays.asList("--xml-output-dir", dir)
                ))
        );
        // In Compatibility Mode, pass classpath and scan directive to the JUnit ConsoleLauncher to avoid
        // "Please specify an explicit selector option or use --scan-class-path or --scan-modules"
        Provider<String> cpString = project.getProviders().provider(() -> testOptions.getClasspath().getAsPath());
        testOptions.getRuntimeArgs().addAll(
                compatModeEnabled().zip(cpString, serializableBiFunctionOf((compat, cp) ->
                        compat ? Arrays.asList("-Djava.class.path=" + cp, "--scan-classpath") : Collections.<String>emptyList()
                ))
        );
        // In Compatibility Mode, also pass -Djava.home from the GraalVM used for the build
        Provider<String> graalVmHome = project.getProviders().provider(() -> {
            NativeImageExecutableLocator.Diagnostics d = new NativeImageExecutableLocator.Diagnostics();
            Provider<JavaLauncher> javaLauncher = testOptions.getJavaLauncher();
            JavaLauncher launcher = javaLauncher.getOrNull();
            if (launcher == null) {
                // Unset binary property: fall back to the plugin default (the same value the
                // convention would supply). §FS-native-invocation.1.2
                javaLauncher = graalExtension.getDefaultJavaLauncher();
                launcher = javaLauncher.getOrNull();
            }
            boolean isExplicit = ((BaseNativeImageOptions) testOptions).getJavaLauncherExplicit().getOrElse(false) && launcher != null;
            File nativeImage = NativeImageExecutableLocator.findNativeImageExecutable(
                    launcher,
                    isExplicit,
                    graalExtension.getToolchainDetection().map(enabled -> !enabled),
                    graalvmHomeProvider(project.getProviders(), d),
                    getExecOperations(),
                    logger,
                    d,
                    NativeImageExecutableLocator.defaultFallbackCandidates(project.getProviders())
            );
            File parent = nativeImage.getParentFile();
            return parent != null ? parent.getParent() : null;
        });
        testOptions.getRuntimeArgs().addAll(
                compatModeEnabled().zip(graalVmHome, serializableBiFunctionOf((compat, home) ->
                        compat && home != null ? Collections.singletonList("-Djava.home=" + home) : Collections.<String>emptyList()
                ))
        );

        TaskProvider<Test> testTask = config.validate().getTestTask();
        testTask.configure(test -> {
            var testList = testResultsDir.dir(test.getName() + "/testlist");
            testListDirectory.set(testList);
            test.getOutputs().dir(testList);
            // Set system property read by the UniqueIdTrackingListener.
            test.systemProperty(JUNIT_PLATFORM_LISTENERS_UID_TRACKING_ENABLED, true);
            TrackingDirectorySystemPropertyProvider directoryProvider = project.getObjects().newInstance(TrackingDirectorySystemPropertyProvider.class);
            directoryProvider.getDirectory().set(testListDirectory);
            test.getJvmArgumentProviders().add(directoryProvider);
            test.doFirst("cleanup test ids", new CleanupTestIdsDirectory(testListDirectory, getFileOperations()));
        });

        // Following ensures that required feature jar is on classpath for every project
        injectTestPluginDependencies(project, name, graalExtension.getTestSupport());
        TaskProvider<BuildNativeImageTask> testImageBuilder = tasks.named(deriveTaskName(name, "native", "Compile"), BuildNativeImageTask.class, task -> {
            task.setOnlyIf(t -> graalExtension.getTestSupport().get() && testListDirectory.getAsFile().get().exists());
            task.getTestListDirectory().set(testListDirectory);
            testTask.get();
            if (!agentProperty(project, graalExtension.getAgent()).get().equals("disabled")) {
                testOptions.getConfigurationFileDirectories().from(AgentConfigurationFactory.getAgentOutputDirectoryForTask(project.getLayout(), testTask.getName()));
            }
            ConfigurableFileCollection testList = project.getObjects().fileCollection();
            // Later this will be replaced by a dedicated task not requiring execution of tests
            testList.from(testListDirectory).builtBy(testTask);
            testOptions.getClasspath().from(testList);
            testOptions.getRuntimeArgs().add("-D" + JUNIT_PLATFORM_LISTENERS_UID_TRACKING_OUTPUT_DIR + "=" + testResultsDir.dir(testTask.getName() + "/testlist").get().getAsFile().getAbsolutePath());
        });
        if (isPrimaryTest) {
            tasks.register(DEPRECATED_NATIVE_TEST_BUILD_TASK, t -> {
                t.setGroup(LifecycleBasePlugin.VERIFICATION_GROUP);
                t.setDescription("Deprecated alias for nativeTestCompile.");
                t.dependsOn(testImageBuilder);
                t.doFirst("Warn about deprecation", task -> task.getLogger().warn("Task " + DEPRECATED_NATIVE_TEST_BUILD_TASK + " is deprecated. Use " + NATIVE_TEST_COMPILE_TASK_NAME + " instead."));
            });
        }

        tasks.named(isPrimaryTest ? NATIVE_TEST_TASK_NAME : "native" + capitalize(name), NativeRunTask.class, task -> {
            task.setGroup(LifecycleBasePlugin.VERIFICATION_GROUP);
            task.setOnlyIf(t -> graalExtension.getTestSupport().get() && testListDirectory.getAsFile().get().exists());
        });
    }

    /**
     * Returns a provider which prefers the CLI arguments over the configured
     * extension value.
     */
    private static Provider<String> agentProperty(Project project, AgentOptions options) {
        return project.getProviders()
            .gradleProperty(AGENT_PROPERTY)
            .map(serializableTransformerOf(v -> {
                if (!v.isEmpty()) {
                    return v;
                }
                return options.getDefaultMode().get();
            }))
            .orElse(options.getEnabled().map(serializableTransformerOf(enabled -> enabled ? options.getDefaultMode().get() : "disabled")));
    }

    private static void registerServiceProvider(Project project, Provider<NativeImageService> nativeImageServiceProvider) {
        project.getTasks()
            .withType(BuildNativeImageTask.class)
            .configureEach(task -> {
                task.usesService(nativeImageServiceProvider);
                task.getService().set(nativeImageServiceProvider);
            });
    }

    private static String capitalize(String name) {
        if (name.length() > 0) {
            return name.substring(0, 1).toUpperCase(Locale.US) + name.substring(1);
        }
        return name;
    }

    private static String prefixFor(String binaryName) {
        return NATIVE_MAIN_EXTENSION.equals(binaryName) ? "" : capitalize(binaryName);
    }

    private static String configurationNameFor(String binaryName, String kind) {
        var prefix = prefixFor(binaryName);
        return "nativeImage" + prefix + capitalize(kind);
    }

    private static String imageClasspathConfigurationNameFor(String binaryName) {
        return configurationNameFor(binaryName, "classpath");
    }

    private static String compileOnlyClasspathConfigurationNameFor(String binaryName) {
        return configurationNameFor(binaryName, "compileOnly");
    }

    @SuppressWarnings("unchecked")
    private static void createNativeConfigurations(Project project, String binaryName, String baseClasspathConfigurationName) {
        ConfigurationContainer configurations = project.getConfigurations();
        Configuration baseClasspath = configurations.getByName(baseClasspathConfigurationName);
        ProviderFactory providers = project.getProviders();
        Configuration compileOnly = configurations.create(compileOnlyClasspathConfigurationNameFor(binaryName), c -> {
            c.setCanBeResolved(false);
            c.setCanBeConsumed(false);
        });
        configurations.create(imageClasspathConfigurationNameFor(binaryName), c -> {
            c.setCanBeConsumed(false);
            c.setCanBeResolved(true);
            c.extendsFrom(compileOnly);
            baseClasspath.getExtendsFrom().forEach(c::extendsFrom);
            c.attributes(attrs -> {
                AttributeContainer baseAttributes = baseClasspath.getAttributes();
                for (Attribute<?> attribute : baseAttributes.keySet()) {
                    Attribute<Object> attr = (Attribute<Object>) attribute;
                    attrs.attributeProvider(attr, providers.provider(() -> baseAttributes.getAttribute(attr)));
                }
            });
        });
        // Native-image classpaths must model the current project through Gradle's supported dependency APIs. §gradle/FS-plugin-model.
        compileOnly.getDependencies().add(project.getDependencies().project(Collections.singletonMap("path", project.getPath())));
    }

    private NativeImageOptions createMainOptions(GraalVMExtension graalExtension, Project project) {
        NativeImageOptions buildExtension = graalExtension.getBinaries().create(NATIVE_MAIN_EXTENSION);
        createNativeConfigurations(
            project,
            NATIVE_MAIN_EXTENSION,
            JavaPlugin.RUNTIME_CLASSPATH_CONFIGURATION_NAME
        );
        var configurations = project.getConfigurations();
        setupExtensionConfigExcludes(buildExtension, configurations);
        buildExtension.getClasspath().from(configurations.getByName(imageClasspathConfigurationNameFor(NATIVE_MAIN_EXTENSION)));
        return buildExtension;
    }


    private NativeImageOptions createTestOptions(GraalVMExtension graalExtension,
                                                 String binaryName,
                                                 Project project,
                                                 NativeImageOptions mainExtension,
                                                 SourceSet sourceSet) {
        createNativeConfigurations(
            project,
            binaryName,
            // Custom native tests use their selected source set runtime classpath. §FS-native-tests.1.1
            sourceSet.getRuntimeClasspathConfigurationName()
        );
        NativeImageOptions testExtension = graalExtension.getBinaries().create(binaryName);
        var configurations = project.getConfigurations();
        setupExtensionConfigExcludes(testExtension, configurations);

        testExtension.getImageName().convention(mainExtension.getImageName().map(name -> name + SharedConstants.NATIVE_TESTS_SUFFIX));

        ConfigurableFileCollection classpath = testExtension.getClasspath();
        classpath.from(configurations.getByName(imageClasspathConfigurationNameFor(binaryName)));
        classpath.from(sourceSet.getOutput().getClassesDirs());
        classpath.from(sourceSet.getOutput().getResourcesDir());
        testExtension.getResources().getDetectionOptions().getEnabled().convention(true);
        // Native tests include test source-set resources by default; omit the generated discovery list. §FS-native-tests.1.
        testExtension.getResources().getDetectionOptions().getDetectionExclusionPatterns().add(JUNIT_PLATFORM_UNIQUE_IDS_RESOURCE_PATTERN);

        return testExtension;
    }

    private static void addExcludeConfigArg(List<String> args, Path jarPath, List<String> listOfResourcePatterns) {
        listOfResourcePatterns.forEach(resourcePattern -> {
            args.add("--exclude-config");
            args.add(Pattern.quote(jarPath.toAbsolutePath().toString()));
            args.add(String.format("%s", resourcePattern));
        });
    }

    private static void setupExtensionConfigExcludes(NativeImageOptions options, ConfigurationContainer configurations) {
        final var imageClasspathConfiguration = configurations.getByName(imageClasspathConfigurationNameFor(options.getName()));
        final var imageClasspathArtifacts = imageClasspathConfiguration.getIncoming().getArtifacts().getResolvedArtifacts();
        options.getExcludeConfigArgs().set(options.getExcludeConfig().map(serializableTransformerOf(excludedConfig -> {
            List<String> args = new ArrayList<>();
            excludedConfig.forEach((entry, listOfResourcePatterns) -> {
                if (entry instanceof File file) {
                    addExcludeConfigArg(args, file.toPath(), listOfResourcePatterns);
                } else if (entry instanceof String dependency) {
                    // Resolve jar for this dependency.
                    imageClasspathArtifacts.get().stream()
                            .filter(artifact -> {
                                if (artifact.getId().getComponentIdentifier() instanceof ModuleComponentIdentifier mid) {
                                    String gav = String.format("%s:%s:%s",
                                        mid.getGroup(),
                                        mid.getModule(),
                                        mid.getVersion()
                                    );
                                    return gav.startsWith(dependency);
                                }
                                return false;
                            })
                            .map(resolvedArtifactResult -> resolvedArtifactResult.getFile().toPath())
                            .forEach(path -> addExcludeConfigArg(args, path, listOfResourcePatterns));
                } else {
                    throw new UnsupportedOperationException("Expected File or GAV coordinate for excludeConfig option, got " + entry.getClass());
                }
            });
            return args;
        })));
    }

    private static List<String> agentSessionDirectories(Directory outputDirectory) {
        return Arrays.stream(Objects.requireNonNull(
                    outputDirectory.getAsFile()
                        .listFiles(file -> file.isDirectory() && file.getName().startsWith("session-"))
                )
            ).map(File::getAbsolutePath)
            .collect(Collectors.toList());
    }

    private void configureAgent(Project project,
                                Provider<String> agentMode,
                                GraalVMExtension graalExtension,
                                TaskProvider<GenerateAgentAccessFilter> defaultAccessFilter,
                                ExecOperations execOperations,
                                FileSystemOperations fileOperations,
                                Task taskToInstrument,
                                JavaForkOptions javaForkOptions) {
        Provider<AgentConfiguration> agentConfiguration = AgentConfigurationFactory.getAgentConfiguration(
                agentMode,
                graalExtension.getAgent(),
                defaultAccessFilter.flatMap(GenerateAgentAccessFilter::getOutputFile));
        Provider<Directory> outputDir = AgentConfigurationFactory.getAgentOutputDirectoryForTask(project.getLayout(), taskToInstrument.getName());
        Provider<JavaLauncher> javaLauncherForAgent = javaLauncherForAgent(project.getProviders());
        // Agent runs prefer an available GraalVM Java without replacing task configuration with a regular JAVA_HOME. §FS-tracing-agent.2.1
        if (agentConfiguration.get().isEnabled()) {
            JavaLauncher javaLauncher = javaLauncherForAgent.getOrNull();
            if (javaLauncher != null) {
                if (taskToInstrument instanceof Test test) {
                    javaForkOptions.setExecutable(null);
                    test.getJavaLauncher().set(javaLauncher);
                } else if (taskToInstrument instanceof JavaExec javaExec) {
                    javaExec.getJavaLauncher().set(javaLauncher);
                    javaForkOptions.setExecutable(javaLauncher.getExecutablePath().getAsFile().getAbsolutePath());
                }
            }
        }
        //noinspection Convert2Lambda
        taskToInstrument.doFirst(new Action<Task>() {
            @Override
            public void execute(@Nonnull Task task) {
                if (agentConfiguration.get().isEnabled()) {
                    // Report where users can find generated tracing-agent metadata. §FS-tracing-agent.4.
                    logger.lifecycle("Instrumenting task with the native-image-agent: "
                            + task.getName()
                            + ". Agent output: "
                            + outputDir.get().getAsFile().getAbsolutePath());
                    JavaLauncher javaLauncher = javaLauncherForAgent.getOrNull();
                    if (javaLauncher != null && !(task instanceof Test) && !(task instanceof JavaExec)) {
                        javaForkOptions.setExecutable(javaLauncher.getExecutablePath().getAsFile().getAbsolutePath());
                    }
                }
            }
        });
        AgentCommandLineProvider cliProvider = project.getObjects().newInstance(AgentCommandLineProvider.class);
        cliProvider.getInputFiles().from(agentConfiguration.map(serializableTransformerOf(AgentConfiguration::getAgentFiles)));
        cliProvider.getEnabled().set(agentConfiguration.map(serializableTransformerOf(AgentConfiguration::isEnabled)));
        cliProvider.getFilterableEntries().set(graalExtension.getAgent().getFilterableEntries());
        cliProvider.getAgentMode().set(agentMode);

        Provider<Boolean> isMergingEnabled = agentConfiguration.map(serializableTransformerOf(AgentConfiguration::isEnabled));
        Provider<AgentMode> agentModeProvider = agentConfiguration.map(serializableTransformerOf(AgentConfiguration::getAgentMode));
        Supplier<List<String>> mergeInputDirs = serializableSupplierOf(() -> outputDir.map(serializableTransformerOf(NativeImagePlugin::agentSessionDirectories)).get());
        Supplier<List<String>> mergeOutputDirs = serializableSupplierOf(() -> outputDir.map(serializableTransformerOf(dir -> Collections.singletonList(dir.getAsFile().getAbsolutePath()))).get());
        cliProvider.getOutputDirectory().set(outputDir);
        cliProvider.getAgentOptions().set(agentConfiguration.map(serializableTransformerOf(AgentConfiguration::getAgentCommandLine)));
        javaForkOptions.getJvmArgumentProviders().add(cliProvider);
        // The generated filter is a declared output and is materialized only during task execution. §FS-tracing-agent.4.1
        taskToInstrument.dependsOn(defaultAccessFilter);

        taskToInstrument.doLast(new MergeAgentFilesAction(
            isMergingEnabled,
            agentModeProvider,
            project.provider(() -> false),
            project.getObjects(),
            javaLauncherForAgentMerge(project, taskToInstrument),
            graalvmHomeProvider(project.getProviders()),
            mergeInputDirs,
            mergeOutputDirs,
            graalExtension.getToolchainDetection().map(enabled -> !enabled),
            project.provider(() -> false),
            execOperations,
            project.getProviders().environmentVariable("GRAALVM_HOME"),
            project.getProviders().environmentVariable("JAVA_HOME"),
            project.getProviders().systemProperty("java.home")));

        taskToInstrument.doLast(new CleanupAgentFilesAction(mergeInputDirs, fileOperations));
    }

    private static Provider<JavaLauncher> javaLauncherForAgent(ProviderFactory providers) {
        return providers.environmentVariable("GRAALVM_HOME")
                .map(serializableTransformerOf(graalHomePath -> javaLauncherForAgentHome(graalHomePath, false)))
                .orElse(providers.environmentVariable("JAVA_HOME")
                        .map(serializableTransformerOf(javaHomePath -> javaLauncherForAgentHome(javaHomePath, true))));
    }

    private static JavaLauncher javaLauncherForAgentHome(String javaHomePath, boolean requireGraalVM) {
        File javaHome = new File(javaHomePath);
        if (requireGraalVM && !isGraalVMHome(javaHome)) {
            return null;
        }
        File javaExecutableFile = new File(javaHome, IS_WINDOWS ? "bin\\java.exe" : "bin/java");
        return javaExecutableFile.exists() ? new FixedJavaLauncher(javaHome, javaExecutableFile) : null;
    }

    private static boolean isGraalVMHome(File javaHome) {
        File release = new File(javaHome, "release");
        if (!release.isFile()) {
            return false;
        }
        Properties properties = new Properties();
        try (var inputStream = java.nio.file.Files.newInputStream(release.toPath())) {
            properties.load(inputStream);
        } catch (Exception ignored) {
            return false;
        }
        return properties.stringPropertyNames().stream()
                .anyMatch(propertyName -> propertyName.toUpperCase(Locale.ROOT).contains("GRAALVM")
                        || String.valueOf(properties.getProperty(propertyName)).toLowerCase(Locale.ROOT).contains("graalvm"));
    }

    private static Property<JavaLauncher> javaLauncherForAgentMerge(Project project, Task task) {
        Property<JavaLauncher> javaLauncher = project.getObjects().property(JavaLauncher.class);
        // Agent post-processing uses the instrumented JVM task launcher when Gradle exposes one. §FS-tracing-agent.5.
        if (task instanceof JavaExec) {
            javaLauncher.convention(((JavaExec) task).getJavaLauncher());
        } else if (task instanceof Test) {
            javaLauncher.convention(((Test) task).getJavaLauncher());
        }
        return javaLauncher;
    }

    private static void injectTestPluginDependencies(Project project, String binaryName, Property<Boolean> testSupportEnabled) {
        project.afterEvaluate(p -> {
            if (testSupportEnabled.get()) {
                var configurations = project.getConfigurations();
                var inferConfigName = imageClasspathConfigurationNameFor(binaryName) + "Internal";
                var missingDependenciesConfig = configurations.create(compileOnlyClasspathConfigurationNameFor(binaryName) + "Auto", cnf -> {
                    cnf.setCanBeResolved(false);
                    cnf.setCanBeConsumed(false);
                });
                var imageClasspath = configurations.getByName(imageClasspathConfigurationNameFor(binaryName));
                var inferConfig = configurations.create(inferConfigName, cnf -> {
                    cnf.setDescription("Infers missing dependencies which are required to run native tests");
                    cnf.setExtendsFrom(imageClasspath.getExtendsFrom());
                    cnf.setCanBeConsumed(false);
                    cnf.setCanBeResolved(true);
                    var attributes = imageClasspath.getAttributes().keySet();
                    cnf.attributes(attrs -> {
                        for (var attribute : attributes) {
                            var key = (Attribute<Object>) attribute;
                            Object value = imageClasspath.getAttributes().getAttribute(key);
                            attrs.attribute(key, value);
                        }
                    });
                });
                // Do not move this up or resolution will fail because we'll create the infer
                // configuration with an unwanted parent config!
                imageClasspath.extendsFrom(missingDependenciesConfig);

                project.getDependencies().add(compileOnlyClasspathConfigurationNameFor(binaryName), "org.graalvm.buildtools:junit-platform-native:" + VersionInfo.JUNIT_PLATFORM_NATIVE_VERSION);
                missingDependenciesConfig
                    .getDependencies()
                    .addAllLater(inferConfig.getIncoming()
                        .getResolutionResult()
                        .getRootComponent()
                        .map(root -> {
                            var allDependencies = new ArrayList<JUnitPlatformNativeDependenciesHelper.DependencyNotation>();
                            var visited = new HashSet<DependencyResult>();
                            var queue = new ArrayDeque<DependencyResult>(root.getDependencies());
                            while (!queue.isEmpty()) {
                                var current = queue.pop();
                                if (visited.add(current) && current instanceof ResolvedDependencyResult resolved) {
                                    if (resolved.getSelected().getId() instanceof ModuleComponentIdentifier mci) {
                                        allDependencies.add(new JUnitPlatformNativeDependenciesHelper.DependencyNotation(mci.getGroup(), mci.getModule(), mci.getVersion()));
                                    }
                                }
                            }
                            return JUnitPlatformNativeDependenciesHelper.inferMissingDependenciesForTestRuntime(allDependencies)
                                .stream()
                                .map(notation -> project.getDependencies().create(notation.groupId() + ":" + notation.artifactId() + ":" + notation.version()))
                                .toList();
                        }));
            }
        });
    }

    private static final class CleanupTestIdsDirectory implements Action<Task> {
        private final DirectoryProperty directory;
        private final FileSystemOperations fsOperations;

        private CleanupTestIdsDirectory(DirectoryProperty directory, FileSystemOperations fsOperations) {
            this.directory = directory;
            this.fsOperations = fsOperations;
        }

        @Override
        public void execute(@Nonnull Task task) {
            File dir = directory.getAsFile().get();
            if (dir.exists()) {
                fsOperations.delete(s -> s.delete(dir));
            }
        }
    }

    public abstract static class TrackingDirectorySystemPropertyProvider implements CommandLineArgumentProvider {
        @OutputDirectory
        public abstract DirectoryProperty getDirectory();

        /**
         * The arguments which will be provided to the process.
         */
        @Override
        public Iterable<String> asArguments() {
            return Collections.singleton("-D" + JUNIT_PLATFORM_LISTENERS_UID_TRACKING_OUTPUT_DIR + "=" + getDirectory().getAsFile().get().getAbsolutePath());
        }
    }

    private static final class FixedJavaLauncher implements JavaLauncher, Serializable {
        private final File javaExecutable;
        private final FixedJavaInstallationMetadata metadata;

        private FixedJavaLauncher(File javaHome, File javaExecutable) {
            this.javaExecutable = javaExecutable;
            this.metadata = new FixedJavaInstallationMetadata(javaHome);
        }

        @Override
        public JavaInstallationMetadata getMetadata() {
            return metadata;
        }

        @Override
        public RegularFile getExecutablePath() {
            return new FixedRegularFile(javaExecutable);
        }
    }

    private static final class FixedJavaInstallationMetadata implements JavaInstallationMetadata, Serializable {
        private final File javaHome;
        private final String javaVersion;

        private FixedJavaInstallationMetadata(File javaHome) {
            this.javaHome = javaHome;
            this.javaVersion = javaVersion(javaHome);
        }

        @Override
        public JavaLanguageVersion getLanguageVersion() {
            return JavaLanguageVersion.of(javaVersion.replaceFirst("^1\\.", "").replaceFirst("[^0-9].*", ""));
        }

        @Override
        public String getJavaRuntimeVersion() {
            return javaVersion;
        }

        @Override
        public String getJvmVersion() {
            return javaVersion;
        }

        @Override
        public String getVendor() {
            return "GraalVM";
        }

        @Override
        public Directory getInstallationPath() {
            return new FixedDirectory(javaHome);
        }

        @Override
        @Internal
        public boolean isCurrentJvm() {
            return false;
        }

        private static String javaVersion(File javaHome) {
            File release = new File(javaHome, "release");
            if (release.isFile()) {
                Properties properties = new Properties();
                try (var inputStream = java.nio.file.Files.newInputStream(release.toPath())) {
                    properties.load(inputStream);
                    String version = properties.getProperty("JAVA_VERSION");
                    if (version != null) {
                        return version.replace("\"", "");
                    }
                } catch (Exception ignored) {
                    // Fall through to the JVM running Gradle.
                }
            }
            return System.getProperty("java.version");
        }
    }

    private static final class FixedRegularFile implements RegularFile, Serializable {
        private final File file;

        private FixedRegularFile(File file) {
            this.file = file;
        }

        @Override
        public File getAsFile() {
            return file;
        }

        @Override
        public String toString() {
            return file.getAbsolutePath();
        }
    }

    private static final class FixedDirectory implements Directory, Serializable {
        private final File directory;

        private FixedDirectory(File directory) {
            this.directory = directory;
        }

        @Override
        public File getAsFile() {
            return directory;
        }

        @Override
        public FileTree getAsFileTree() {
            throw new UnsupportedOperationException();
        }

        @Override
        public Directory dir(String path) {
            return new FixedDirectory(new File(directory, path));
        }

        @Override
        public Provider<Directory> dir(Provider<? extends CharSequence> path) {
            return path.map(serializableTransformerOf(value -> dir(value.toString())));
        }

        @Override
        public RegularFile file(String path) {
            return new FixedRegularFile(new File(directory, path));
        }

        @Override
        public Provider<RegularFile> file(Provider<? extends CharSequence> path) {
            return path.map(serializableTransformerOf(value -> file(value.toString())));
        }

        @Override
        public FileCollection files(Object... paths) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String toString() {
            return directory.getAbsolutePath();
        }
    }

    private static final class ExcludeEntry {
        private final String gav;
        private final List<String> excludes;

        private ExcludeEntry(String gav, List<String> excludes) {
            this.gav = gav;
            this.excludes = excludes;
        }

        public String getGav() {
            return gav;
        }

        public List<String> getExcludes() {
            return excludes;
        }
    }

    // -----------------------------
    // Compatibility Mode Detection
    // -----------------------------

    /**
     * Exposes the Compatibility Mode detection for the test binary.
     * Follow-up tasks will use this provider to gate configuration/skip tasks.
     */
    public Provider<Boolean> compatModeEnabled() {
        return compatModeEnabled;
    }

    private static Provider<Boolean> computeCompatibilityModeEnabledProvider(Project project, NativeImageOptions options) {
        ProviderFactory providers = project.getProviders();

        // System environment: NATIVE_IMAGE_OPTIONS
        Provider<Boolean> fromSystemEnv = providers.environmentVariable(NATIVE_IMAGE_OPTIONS_ENV)
                .map(NativeImagePlugin::containsCompatibilityTokenInString)
                .orElse(false);

        // Options-level environment variables
        Provider<Boolean> fromOptionsEnv = options.getEnvironmentVariables()
                .map(env -> {
                    Object v = env.get(NATIVE_IMAGE_OPTIONS_ENV);
                    return v != null && containsCompatibilityTokenInString(String.valueOf(v));
                })
                .orElse(false);

        // Build args on the test options
        Provider<Boolean> fromBuildArgs = options.getBuildArgs()
                .map(NativeImagePlugin::containsCompatibilityTokenInArgs)
                .orElse(false);

        // Combine: true if any source enables compatibility mode
        Provider<Boolean> anyEnv = fromSystemEnv.zip(fromOptionsEnv, (a, b) -> a || b);
        return anyEnv.zip(fromBuildArgs, (ab, c) -> ab || c);
    }

    private static boolean containsCompatibilityTokenInString(String value) {
        return value != null && value.contains(COMPATIBILITY_MODE_TOKEN);
    }

    public static boolean containsCompatibilityTokenInArgs(List<String> args) {
        return args != null && args.stream()
                .filter(Objects::nonNull)
                .anyMatch(s -> s.equals(COMPATIBILITY_MODE_TOKEN));
    }
}
