/*
 * Copyright (c) 2021, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.graalvm.buildtools.gradle.internal;

import groovy.lang.Closure;
import groovy.lang.GroovyObjectSupport;
import org.codehaus.groovy.runtime.InvokerHelper;
import org.graalvm.buildtools.gradle.NativeImagePlugin;
import org.graalvm.buildtools.gradle.dsl.GraalVMExtension;
import org.graalvm.buildtools.gradle.dsl.NativeImageOptions;
import org.graalvm.buildtools.gradle.dsl.NativeImageLayer;
import org.graalvm.buildtools.gradle.dsl.agent.AgentOptions;
import org.gradle.api.Action;
import org.gradle.api.NamedDomainObjectContainer;
import org.gradle.api.Project;
import org.gradle.api.Task;
import org.gradle.api.plugins.JavaPluginExtension;
import org.gradle.api.provider.Property;
import org.gradle.api.provider.Provider;
import org.gradle.jvm.toolchain.JavaLauncher;
import org.gradle.jvm.toolchain.JavaToolchainService;

import javax.inject.Inject;
import java.util.function.Predicate;

public abstract class DefaultGraalVmExtension implements GraalVMExtension {
    private final transient NamedDomainObjectContainer<NativeImageOptions> nativeImages;
    private final transient NamedDomainObjectContainer<NativeImageLayer> layers;
    private final transient NativeImagePlugin plugin;
    private final transient Project project;
    private final Property<JavaLauncher> defaultJavaLauncher;

    @Inject
    public DefaultGraalVmExtension(NamedDomainObjectContainer<NativeImageOptions> nativeImages,
                                   NamedDomainObjectContainer<NativeImageLayer> layers,
                                   NativeImagePlugin plugin,
                                   Project project) {
        this.nativeImages = nativeImages;
        this.layers = layers;
        this.plugin = plugin;
        this.project = project;
        this.defaultJavaLauncher = project.getObjects().property(JavaLauncher.class);
        getToolchainDetection().convention(false);
        // Restore the public javaLauncher convention on every binary: the property resolves
        // from the default (toolchain-selected) launcher, with provenance tracked so the
        // plugin can tell convention-sourced values apart from explicit assignments.
        // §FS-native-invocation.1.2
        nativeImages.configureEach(options ->
                ((BaseNativeImageOptions) options).setJavaLauncherConvention(defaultJavaLauncher));
        getTestSupport().convention(true);
        AgentOptions agentOpts = getAgent();
        agentOpts.getDefaultMode().convention("standard");
        agentOpts.getEnabled().convention(false);
        agentOpts.getModes().getConditional().getParallel().convention(true);
        agentOpts.getMetadataCopy().getMergeWithExisting().convention(false);
        agentOpts.getBuiltinHeuristicFilter().convention(true);
        agentOpts.getBuiltinCallerFilter().convention(true);
        agentOpts.getEnableExperimentalPredefinedClasses().convention(false);
        agentOpts.getEnableExperimentalUnsafeAllocationTracing().convention(true);
        agentOpts.getTrackReflectionMetadata().convention(true);
        configureToolchain();
    }

    public Provider<JavaLauncher> getDefaultJavaLauncher() {
        return defaultJavaLauncher;
    }

    private void configureToolchain() {
        defaultJavaLauncher.convention(
                getToolchainDetection().flatMap(enabled -> {
                    if (!enabled) {
                        return null;
                    }
                    JavaToolchainService toolchainService = project.getExtensions().findByType(JavaToolchainService.class);
                    if (toolchainService == null) {
                        return null;
                    }
                    // Resolve the toolchain launcher for the configured Java toolchain.
                    // This keeps graalvmNative.binaries.main.javaLauncher queryable (e.g. its
                    // metadata.languageVersion) whenever toolchain detection is enabled.
                    // Whether the toolchain actually contains native-image is decided at build
                    // time by NativeImageExecutableLocator, which falls back to GRAALVM_HOME
                    // when the launcher's installation lacks it. §FS-native-invocation.1.6
                    JavaPluginExtension javaConvention = project.getExtensions().getByType(JavaPluginExtension.class);
                    return toolchainService.launcherFor(javaConvention.getToolchain());
                })
        );
    }

    @Override
    public NamedDomainObjectContainer<NativeImageOptions> getBinaries() {
        return nativeImages;
    }

    @Override
    public NamedDomainObjectContainer<NativeImageLayer> getLayers() {
        return layers;
    }

    @Override
    public void agent(Action<? super AgentOptions> spec) {
        spec.execute(getAgent());
    }

    @Override
    public void agent(Closure<?> spec) {
        Closure<?> configuredSpec = (Closure<?>) spec.clone();
        configuredSpec.setDelegate(new AgentOptionsGroovyDslAdapter(getAgent()));
        configuredSpec.setResolveStrategy(Closure.DELEGATE_FIRST);
        configuredSpec.call();
    }

    /**
     * Adapts Groovy's direct closure assignment to the managed predicate property. §FS-tracing-agent.2.
     */
    private static final class AgentOptionsGroovyDslAdapter extends GroovyObjectSupport {
        private final AgentOptions options;

        private AgentOptionsGroovyDslAdapter(AgentOptions options) {
            this.options = options;
        }

        @Override
        public Object getProperty(String property) {
            return InvokerHelper.getProperty(options, property);
        }

        @Override
        public void setProperty(String property, Object value) {
            if ("tasksToInstrumentPredicate".equals(property) && value instanceof Closure<?>) {
                Closure<?> predicateClosure = (Closure<?>) value;
                Predicate<Task> predicate = task -> Boolean.TRUE.equals(predicateClosure.call(task));
                options.getTasksToInstrumentPredicate().set(predicate);
                return;
            }
            InvokerHelper.setProperty(options, property, value);
        }

        @Override
        public Object invokeMethod(String name, Object arguments) {
            return InvokerHelper.invokeMethod(options, name, arguments);
        }
    }

    @Override
    public void binaries(Action<? super NamedDomainObjectContainer<NativeImageOptions>> spec) {
        spec.execute(nativeImages);
    }

    @Override
    public void layers(Action<? super NamedDomainObjectContainer<NativeImageLayer>> spec) {
        spec.execute(layers);
    }

    @Override
    public void registerTestBinary(String name, Action<? super TestBinaryConfig> spec) {
        DefaultTestBinaryConfig config = project.getObjects().newInstance(DefaultTestBinaryConfig.class, name);
        spec.execute(config);
        plugin.registerTestBinary(project, this, config);
    }
}
