/*
 * Copyright (c) 2020, 2021 Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.graalvm.buildtools.maven;

import org.apache.maven.AbstractMavenLifecycleParticipant;
import org.apache.maven.execution.MavenSession;
import org.apache.maven.model.Build;
import org.apache.maven.model.Plugin;
import org.apache.maven.model.PluginExecution;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.logging.LogEnabled;
import org.codehaus.plexus.logging.Logger;
import org.codehaus.plexus.util.xml.Xpp3Dom;
import org.graalvm.buildtools.agent.AgentConfiguration;
import org.graalvm.buildtools.utils.AgentUtils;
import org.graalvm.buildtools.utils.SharedConstants;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static org.graalvm.buildtools.utils.NativeImageConfigurationUtils.getNativeImage;

/**
 * This extension is responsible for configuring the Surefire plugin to enable
 * the JUnit Platform test listener and registering the native dependency transparently.
 */
@Component(role = AbstractMavenLifecycleParticipant.class, hint = "native-build-tools")
public class NativeExtension extends AbstractMavenLifecycleParticipant implements LogEnabled {

    private static final String JUNIT_PLATFORM_LISTENERS_UID_TRACKING_ENABLED = "junit.platform.listeners.uid.tracking.enabled";
    private static final String JUNIT_PLATFORM_LISTENERS_UID_TRACKING_OUTPUT_DIR = "junit.platform.listeners.uid.tracking.output.dir";
    private static final String NATIVEIMAGE_IMAGECODE = "org.graalvm.nativeimage.imagecode";
    private static final String SYSTEM_PROPERTY_VARIABLES = "systemPropertyVariables";
    private static final String AGENT_EXECUTION_ID = "agentExecutionId";
    private static final String DEFAULT_AGENT_EXECUTION_ID = "java-agent";

    private static Logger logger;

    private Path sessionAgentConfigDirectory;

    @Override
    public void enableLogging(Logger logger) {
        this.logger = logger;
    }

    /**
     * Enumeration of execution contexts.
     * <p>Enum constants are intentionally lowercase for use as directory names
     * and within the Maven POM as values of the {@code name} attribute in
     * {@code <options name="...">}.
     */
    enum Context {main, test}

    static String testIdsDirectory(String baseDir) {
        return baseDir + File.separator + "test-ids";
    }

    static String testIdsDirectory(String baseDir, String pluginName) {
        return baseDir + File.separator + pluginName + "-test-ids";
    }

    static String buildAgentArgument(String baseDir, Context context, List<String> agentOptions) {
        List<String> options = new ArrayList<>(agentOptions);
        String effectiveOutputDir = agentOutputDirectoryFor(baseDir, context);
        if (context == Context.test) {
            // We need to patch the config dir IF, and only IF, we are running tests, because
            // test execution can be forked into a separate process and there's a race condition.
            // We have to special case testing here instead of using a generic strategy THEN
            // invoke the merging tool, because there's no way in Maven to do something as easy
            // as finalizing a goal (that is, let me do the merge AFTER you're done executing tests,
            // or invoking exec, or whatever, because what I need to do actually participates into
            // the same unit of work !).
            effectiveOutputDir = effectiveOutputDir + File.separator + SharedConstants.AGENT_SESSION_SUBDIR;
        }
        String finalEffectiveOutputDir = effectiveOutputDir;
        options = options.stream().map(option -> option.contains("{output_dir}") ? option.replace("{output_dir}", finalEffectiveOutputDir) : option).collect(Collectors.toList());
        return "-agentlib:native-image-agent=" + String.join(",", options);
    }

    static String quoteAgentArgumentForArgLine(String agentArgument) {
        if (!agentArgument.contains(" ")) {
            return agentArgument;
        }
        if (!agentArgument.contains("\"")) {
            return "\"" + agentArgument + "\"";
        }
        if (!agentArgument.contains("'")) {
            return "'" + agentArgument + "'";
        }
        return agentArgument;
    }

    static String appendAgentArgument(String existingArgLine, String agentArgument) {
        String quotedAgentArgument = quoteAgentArgumentForArgLine(agentArgument);
        return existingArgLine == null || existingArgLine.isBlank()
                ? quotedAgentArgument
                : existingArgLine + " " + quotedAgentArgument;
    }

    static String agentOutputDirectoryFor(String baseDir, Context context) {
        return (baseDir + "/native/agent-output/" + context).replace('/', File.separatorChar);
    }

    @Override
    public void afterProjectsRead(MavenSession session) {
        for (MavenProject project : session.getProjects()) {
            Build build = project.getBuild();
            withPlugin(build, "native-maven-plugin", nativePlugin -> {
                String target = build.getDirectory();

                Xpp3Dom configurationRoot = (Xpp3Dom) nativePlugin.getConfiguration();
                AgentConfiguration agent;
                try {
                    agent = AgentUtils.collectAgentProperties(session, configurationRoot, this::defaultAccessFilter);
                    if (agent.isEnabled()) {
                        // Keep the generated filter outside target so a later clean cannot remove it.
                        // §FS-tracing-agent.3.1
                        AgentConfiguration.writeDefaultAccessFilter(defaultAccessFilter());
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                Set<Context> instrumentedContexts = EnumSet.noneOf(Context.class);

                // Test configuration
                List<String> plugins = List.of("maven-surefire-plugin", "maven-failsafe-plugin");
                for (String pluginName : plugins) {
                    withPlugin(build, pluginName, plugin -> {
                        // Keep each test provider's selected test IDs isolated. §FS-native-tests.6.
                        String testIdsDir = testIdsDirectory(target, plugin.getArtifactId());
                        configureJunitListener(plugin, testIdsDir);
                        if (agent.isEnabled()) {
                            List<String> agentOptions = agent.getAgentCommandLine();
                            if (configureAgentForPlugin(plugin, buildAgentArgument(target, Context.test, agentOptions))) {
                                instrumentedContexts.add(Context.test);
                            }
                        }
                    });
                }

                // Main configuration
                if (agent.isEnabled()) {
                    String agentExecutionId = mainAgentExecutionId(configurationRoot);
                    withPlugin(build, "exec-maven-plugin", execPlugin ->
                            updatePluginConfiguration(execPlugin, (exec, config) -> {
                                if (agentExecutionId.equals(exec.getId())) {
                                    instrumentedContexts.add(Context.main);
                                    Xpp3Dom commandlineArgs = findOrAppend(config, "arguments");
                                    Xpp3Dom[] arrayOfChildren = commandlineArgs.getChildren();
                                    for (int i = 0; i < arrayOfChildren.length; i++) {
                                        commandlineArgs.removeChild(0);
                                    }
                                    List<Xpp3Dom> children = new ArrayList<>();
                                    Collections.addAll(children, arrayOfChildren);

                                    // Agent argument
                                    Xpp3Dom arg = new Xpp3Dom("argument");
                                    List<String> agentOptions = agent.getAgentCommandLine();
                                    arg.setValue(buildAgentArgument(target, Context.main, agentOptions));
                                    children.add(0, arg);

                                    // System property for org.graalvm.nativeimage.imagecode
                                    arg = new Xpp3Dom("argument");
                                    arg.setValue("-D" + NATIVEIMAGE_IMAGECODE + "=agent");
                                    children.add(1, arg);

                                    for (Xpp3Dom child : children) {
                                        commandlineArgs.addChild(child);
                                    }
                                    // Main application agent binding follows the configured execution ID. §FS-tracing-agent.3.
                                    findOrAppend(config, "executable").setValue(getGraalvmJava());
                                }
                            })
                    );
                    updatePluginConfiguration(nativePlugin, (exec, configuration) -> {
                        Context context = contextForNativeExecution(exec);
                        Xpp3Dom agentResourceDirectory = findOrAppend(configuration, "agentResourceDirectory");
                        agentResourceDirectory.setValue(agentOutputDirectoryFor(target, context));
                        setupMergeAgentFiles(exec, configuration, context);
                    });
                    instrumentedContexts.forEach(context -> logAgentOutput(target, context));
                }
            });
        }
    }

    static Path createSessionAgentConfigDirectory() {
        try {
            return Files.createTempDirectory("native-build-tools-agent-config-");
        } catch (IOException e) {
            throw new RuntimeException("Cannot create the native-image-agent session configuration directory", e);
        }
    }

    private Path defaultAccessFilter() {
        if (sessionAgentConfigDirectory == null) {
            sessionAgentConfigDirectory = createSessionAgentConfigDirectory();
        }
        return AgentConfiguration.getDefaultAccessFilterPath(sessionAgentConfigDirectory);
    }

    @Override
    public void afterSessionEnd(MavenSession session) {
        if (sessionAgentConfigDirectory == null) {
            return;
        }
        try {
            deleteSessionAgentConfigDirectory(sessionAgentConfigDirectory);
        } catch (IOException e) {
            logger.warn("Cannot delete native-image-agent session configuration directory " + sessionAgentConfigDirectory + ".", e);
        } finally {
            sessionAgentConfigDirectory = null;
        }
    }

    // Deletes the filter before its parent directory so each enabled session leaves no temporary state. §FS-tracing-agent.3.1
    static void deleteSessionAgentConfigDirectory(Path agentConfigDirectory) throws IOException {
        Files.deleteIfExists(AgentConfiguration.getDefaultAccessFilterPath(agentConfigDirectory));
        Files.deleteIfExists(agentConfigDirectory);
    }

    /**
     * Resolves the tracing-agent context for a native plugin execution. §FS-tracing-agent.3.
     */
    static Context contextForNativeExecution(PluginExecution execution) {
        return execution.getGoals().stream().anyMatch(NativeExtension::isNativeTestGoal) ? Context.test : Context.main;
    }

    private static boolean isNativeTestGoal(String goal) {
        return NativeTestMojo.TEST_GOAL.equals(goal) || NativeTestMojo.INTEGRATION_TEST_GOAL.equals(goal);
    }

    static String mainAgentExecutionId(Xpp3Dom configurationRoot) {
        if (configurationRoot != null) {
            Xpp3Dom agentExecutionId = configurationRoot.getChild(AGENT_EXECUTION_ID);
            if (agentExecutionId != null && agentExecutionId.getValue() != null && !agentExecutionId.getValue().trim().isEmpty()) {
                return agentExecutionId.getValue().trim();
            }
        }
        return DEFAULT_AGENT_EXECUTION_ID;
    }

    private static void setupMergeAgentFiles(PluginExecution exec, Xpp3Dom configuration, Context context) {
        List<String> goals = new ArrayList<>();
        goals.add("merge-agent-files");
        goals.addAll(exec.getGoals());
        exec.setGoals(goals);
        Xpp3Dom agentContext = findOrAppend(configuration, "context");
        agentContext.setValue(context.name());
    }

    private static void withPlugin(Build build, String artifactId, Consumer<? super Plugin> consumer) {
        build.getPlugins()
                .stream()
                .filter(p -> artifactId.equals(p.getArtifactId()))
                .findFirst()
                .ifPresent(consumer);
    }

    private static boolean configureAgentForPlugin(Plugin plugin, String agentArgument) {
        if (plugin.getExecutions().isEmpty()) {
            return false;
        }
        updatePluginConfiguration(plugin, (exec, configuration) -> {
            Xpp3Dom systemPropertyVariables = findOrAppend(configuration, SYSTEM_PROPERTY_VARIABLES);
            Xpp3Dom agent = findOrAppend(systemPropertyVariables, NATIVEIMAGE_IMAGECODE);
            agent.setValue("agent");
            Xpp3Dom argLine = findOrAppend(configuration, "argLine");
            // Surefire/Failsafe parse argLine as one command-line string.
            // Preserve user-supplied JVM options while keeping spaced output paths as one argument. §FS-tracing-agent.3.
            argLine.setValue(appendAgentArgument(argLine.getValue(), agentArgument));
            findOrAppend(configuration, "jvm").setValue(getGraalvmJava());
        });
        return true;
    }

    private static void logAgentOutput(String baseDir, Context context) {
        String execution = context == Context.test ? "test" : "application";
        String outputDirectory = new File(agentOutputDirectoryFor(baseDir, context)).getAbsolutePath();
        // Report where users can find generated tracing-agent metadata. §FS-tracing-agent.3.
        logger.info("Instrumenting Maven " + execution + " execution with the native-image-agent. Agent output: " + outputDirectory);
    }

    private static void configureJunitListener(Plugin surefirePlugin, String testIdsDir) {
        updatePluginConfiguration(surefirePlugin, (exec, configuration) -> {
            Xpp3Dom systemPropertyVariables = findOrAppend(configuration, SYSTEM_PROPERTY_VARIABLES);
            Xpp3Dom junitTracking = findOrAppend(systemPropertyVariables, JUNIT_PLATFORM_LISTENERS_UID_TRACKING_ENABLED);
            Xpp3Dom testIdsProperty = findOrAppend(systemPropertyVariables, JUNIT_PLATFORM_LISTENERS_UID_TRACKING_OUTPUT_DIR);
            junitTracking.setValue("true");
            testIdsProperty.setValue(testIdsDir);
        });
    }

    private static void updatePluginConfiguration(Plugin plugin, BiConsumer<PluginExecution, ? super Xpp3Dom> consumer) {
        plugin.getExecutions().forEach(exec -> {
            Xpp3Dom configuration = configurationBlockOf(exec);
            consumer.accept(exec, configuration);
        });
    }

    private static Xpp3Dom configurationBlockOf(PluginExecution exec) {
        Xpp3Dom configuration = (Xpp3Dom) exec.getConfiguration();
        if (configuration == null) {
            configuration = new Xpp3Dom("configuration");
            exec.setConfiguration(configuration);
        }
        return configuration;
    }

    private static Xpp3Dom findOrAppend(Xpp3Dom parent, String childName) {
        Xpp3Dom child = parent.getChild(childName);
        if (child == null) {
            child = new Xpp3Dom(childName);
            parent.addChild(child);
        }
        return child;
    }

    private static String getGraalvmJava() {
        try {
            return getNativeImage(logger).getParent().resolve("java").toString();
        } catch (MojoExecutionException e) {
            throw new RuntimeException(e);
        }
    }

}
