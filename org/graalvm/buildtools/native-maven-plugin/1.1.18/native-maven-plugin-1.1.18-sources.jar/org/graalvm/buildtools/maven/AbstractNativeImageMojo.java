/*
 * Copyright (c) 2020, 2022, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.graalvm.buildtools.maven;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.execution.MavenSession;
import org.apache.maven.model.Exclusion;
import org.apache.maven.plugin.MojoExecution;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.descriptor.PluginDescriptor;
import org.apache.maven.plugins.annotations.Component;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.apache.maven.toolchain.ToolchainManager;
import org.codehaus.plexus.logging.Logger;
import org.eclipse.aether.artifact.DefaultArtifact;
import org.eclipse.aether.resolution.ArtifactRequest;
import org.eclipse.aether.resolution.ArtifactResolutionException;
import org.graalvm.buildtools.maven.config.ExcludeConfigConfiguration;
import org.graalvm.buildtools.maven.config.UseLayerConfiguration;
import org.graalvm.buildtools.model.resources.NativeImageFlags;
import org.graalvm.buildtools.utils.NativeImageConfigurationUtils;
import org.graalvm.buildtools.utils.NativeImageUtils;
import org.graalvm.buildtools.utils.NativeImageLayerArguments;
import org.graalvm.buildtools.utils.NativeImageLayerRuntime;
import org.graalvm.buildtools.utils.SchemaValidationUtils;
import org.graalvm.buildtools.utils.SharedConstants;
import org.graalvm.reachability.internal.FileSystemRepository;

import javax.inject.Inject;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemAlreadyExistsException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.graalvm.buildtools.utils.NativeImageUtils.ORACLE_GRAALVM_IDENTIFIER;

/**
 * Base mojo for Maven native-image workflows, including executable lookup and schema validation.
 * It implements §FS-native-builds, §FS-config-model.4, and §FS-resources-and-metadata.4.
 * @author Sebastien Deleuze
 */
public abstract class AbstractNativeImageMojo extends AbstractNativeMojo {
    protected static final String NATIVE_IMAGE_META_INF = "META-INF/native-image";
    protected static final String NATIVE_IMAGE_PROPERTIES_FILENAME = "native-image.properties";
    protected static final String NATIVE_IMAGE_DRY_RUN = "nativeDryRun";
    private static final Pattern LAYER_CREATE_ARG = Pattern.compile(
            Pattern.quote(NativeImageFlags.LAYER_CREATE) + "(@[^=]*)?=.+");
    private static String nativeImageVersionInformation = null;
    private List<Artifact> resolvedLayerUseArtifacts;
    private List<Path> resolvedLayerRuntimeDirectories;

    @Parameter(defaultValue = "${plugin}", readonly = true) // Maven 3 only
    protected PluginDescriptor plugin;

    @Parameter(defaultValue = "${session}", readonly = true)
    protected MavenSession session;

    @Parameter(defaultValue = "${mojoExecution}")
    protected MojoExecution mojoExecution;

    @Parameter(property = "plugin.artifacts", required = true, readonly = true)
    protected List<Artifact> pluginArtifacts;

    @Parameter(defaultValue = "${project.build.directory}", property = "outputDir", required = true)
    protected File outputDirectory;

    @Parameter(property = "mainClass")
    protected String mainClass;

    @Parameter(property = "imageName", defaultValue = "${project.artifactId}")
    protected String imageName;

    @Parameter(property = "classpath")
    protected List<String> classpath;

    @Parameter(property = "classesDirectory")
    protected File classesDirectory;

    @Parameter(defaultValue = "${project.build.outputDirectory}", readonly = true, required = true)
    protected File defaultClassesDirectory;

    protected final List<Path> imageClasspath;

    @Parameter(property = "debug", defaultValue = "false")
    protected boolean debug;

    /**
     * Native Image fallback support was removed in GraalVM 25.1, making this parameter a no-op
     * there. The parameter remains functional with older GraalVM versions. §FS-config-model.1.
     *
     * @deprecated Native Image fallback support was removed in GraalVM 25.1.
     */
    @Parameter(property = "fallback", defaultValue = "false")
    @Deprecated
    protected boolean fallback;

    @Parameter(property = "verbose", defaultValue = "false")
    protected boolean verbose;

    @Parameter(property = "sharedLibrary", defaultValue = "false")
    protected boolean sharedLibrary;

    @Parameter(property = "quickBuild", defaultValue = "false")
    protected boolean quickBuild;

    @Parameter(property = "useArgFile")
    protected Boolean useArgFile;

    @Parameter(property = "buildArgs")
    protected List<String> buildArgs;

    @Parameter(defaultValue = "${project.build.directory}/native/generated", property = "resourcesConfigDirectory", required = true)
    protected File resourcesConfigDirectory;

    @Parameter(property = "agentResourceDirectory")
    protected File agentResourceDirectory;

    @Parameter(property = "excludeConfig")
    protected List<ExcludeConfigConfiguration> excludeConfig;

    @Parameter(alias = "environmentVariables", property = "environmentVariables")
    protected Map<String, String> environment;

    @Parameter(alias = "systemPropertyVariables", property = "systemPropertyVariables")
    protected Map<String, String> systemProperties;

    @Parameter(property = "configurationFileDirectories")
    protected List<String> configFiles;

    @Parameter(property = "jvmArgs")
    protected List<String> jvmArgs;

    @Parameter(property = "runtimeArgs")
    protected List<String> runtimeArgs;

    @Parameter(property = NATIVE_IMAGE_DRY_RUN, defaultValue = "false")
    protected boolean dryRun;

    @Parameter(property = "requiredVersion")
    protected String requiredVersion;

    @Parameter(property = "exclusions")
    protected List<Exclusion> exclusions;

    @Parameter(property = "useLayers")
    protected List<UseLayerConfiguration> useLayers;

    @Component
    protected ToolchainManager toolchainManager;

    /**
        Set this to true to ensure that native-image is found in your toolchain and not in an unrelated JDK or in your PATH.
        Will fail the build in case no toolchain was found or if it does not contain native-image.
    */
    @Parameter(property = "enforceToolchain")
    protected boolean enforceToolchain;

    @Inject
    protected AbstractNativeImageMojo() {
        imageClasspath = new ArrayList<>();
        useArgFile = SharedConstants.IS_WINDOWS;
    }

    protected List<String> getBuildArgs() throws MojoExecutionException {
        final List<String> cliArgs = new ArrayList<>();

        if (excludeConfig != null) {
            excludeConfig.forEach(entry -> {
                cliArgs.add("--exclude-config");
                cliArgs.add(entry.getJarPath());
                cliArgs.add(String.format("\"%s\"", entry.getResourcePattern()));
            });
        }

        String imageClasspath = getClasspath();
        if (!imageClasspath.isEmpty()) {
            cliArgs.add("-cp");
            cliArgs.add(imageClasspath);
        }

        if (debug) {
            cliArgs.add("-g");
        }
        // GraalVM 25.1 removed fallback; unknown releases retain the compatibility flag. §FS-config-model.1.
        if (!fallback && !isFallbackRemoved()) {
            cliArgs.add("--no-fallback");
        }
        if (verbose) {
            cliArgs.add("--verbose");
        }
        if (sharedLibrary) {
            cliArgs.add("--shared");
        }

        // Let's allow user to specify environment option to toggle quick build.
        String quickBuildEnv = System.getenv("GRAALVM_QUICK_BUILD");
        if (quickBuildEnv != null) {
            logger.warn("Quick build environment variable is set.");
            quickBuild = quickBuildEnv.isEmpty() || Boolean.parseBoolean(quickBuildEnv);
        }

        if (quickBuild) {
            cliArgs.add("-Ob");
        }

        addConsoleColorArgument(cliArgs);

        cliArgs.add("-o");
        cliArgs.add(outputDirectory.toPath().toAbsolutePath() + File.separator + imageName);

        if (systemProperties != null) {
            for (Map.Entry<String, String> entry : systemProperties.entrySet()) {
                cliArgs.add("-D" + entry.getKey() + "=" + entry.getValue());
            }
        }

        if (environment != null) {
            for (Map.Entry<String, String> entry : environment.entrySet()) {
                cliArgs.add("-E" + entry.getKey() + "=" + entry.getValue());
            }
        }

        if (jvmArgs != null) {
            jvmArgs.forEach(jvmArg -> cliArgs.add("-J" + jvmArg));
        }

        maybeAddGeneratedResourcesConfig(buildArgs);
        maybeAddReachabilityMetadata(configFiles);

        if (configFiles != null && !configFiles.isEmpty()) {
            cliArgs.add("-H:ConfigurationFileDirectories=" +
                    configFiles.stream()
                    .map(Paths::get)
                    .map(Path::toAbsolutePath)
                    .map(Path::toString)
                    .collect(Collectors.joining(","))
            );
        }

        List<String> layerUseArgs = resolveLayerUseArguments();
        if (!layerUseArgs.isEmpty()) {
            cliArgs.add(NativeImageFlags.UNLOCK_EXPERIMENTAL_VMOPTIONS);
            cliArgs.addAll(layerUseArgs);
        }

        if (buildArgs != null && !buildArgs.isEmpty()) {
            cliArgs.addAll(processBuildArgs(buildArgs));
        }

        List<String> actualCliArgs;
        if (useArgFile) {
            Path tmpDir = Paths.get("target", "tmp");
            actualCliArgs = new ArrayList<>(NativeImageUtils.convertToArgsFile(cliArgs, tmpDir));
        } else {
            actualCliArgs = cliArgs;
        }

        /* Main class comes last. It is kept outside argument files as GraalVM releases before JDK 21 fail to detect the mainClass in these files. */
        if (mainClass != null && !mainClass.equals(".")) {
            actualCliArgs.add(mainClass);
        }
        return Collections.unmodifiableList(actualCliArgs);
    }

    // Maven-exposed console modes control version-appropriate Native Image color flags. §FS-native-builds.9.
    private void addConsoleColorArgument(List<String> cliArgs) throws MojoExecutionException {
        Optional<Boolean> colorEnabled = getMavenColorSetting();
        if (colorEnabled.isEmpty()) {
            return;
        }
        if (getNativeImageMajorVersion() >= 21) {
            cliArgs.add(NativeImageFlags.COLOR + (colorEnabled.get() ? "=always" : "=never"));
        } else {
            cliArgs.add(colorEnabled.get()
                    ? NativeImageFlags.BUILD_OUTPUT_COLORFUL
                    : NativeImageFlags.BUILD_OUTPUT_COLORLESS);
        }
    }

    protected Optional<Boolean> getMavenColorSetting() {
        String styleColor = session.getUserProperties().getProperty("style.color");
        if (styleColor == null) {
            styleColor = session.getSystemProperties().getProperty("style.color");
        }
        Optional<Boolean> explicitStyleColor = parseMavenColorMode(styleColor);
        if (explicitStyleColor.isPresent()) {
            return explicitStyleColor;
        }

        if (!session.getRequest().isInteractiveMode()) {
            return Optional.of(false);
        }
        return Optional.empty();
    }

    private static Optional<Boolean> parseMavenColorMode(String colorMode) {
        if ("always".equalsIgnoreCase(colorMode)
                || "yes".equalsIgnoreCase(colorMode)
                || "force".equalsIgnoreCase(colorMode)) {
            return Optional.of(true);
        }
        if ("never".equalsIgnoreCase(colorMode)
                || "no".equalsIgnoreCase(colorMode)
                || "none".equalsIgnoreCase(colorMode)) {
            return Optional.of(false);
        }
        return Optional.empty();
    }

    protected int getNativeImageMajorVersion() throws MojoExecutionException {
        Path executable = NativeImageConfigurationUtils.getNativeImageSupportingToolchain(
                logger, toolchainManager, session, enforceToolchain);
        return NativeImageUtils.getMajorJDKVersion(getVersionInformation(logger, executable));
    }

    protected boolean isFallbackRemoved() throws MojoExecutionException {
        Path executable = NativeImageConfigurationUtils.getNativeImageSupportingToolchain(
                logger, toolchainManager, session, enforceToolchain);
        return NativeImageUtils.isGraalVMVersionAtLeast(getVersionInformation(logger, executable), 25, 1);
    }

    static List<String> processBuildArgs(List<String> buildArgs) {
        var result = new ArrayList<String>();
        for (String buildArg : buildArgs) {
            if (buildArg.startsWith("\\Q") || buildArg.startsWith("-H:ConfigurationFileDirectories")) {
                result.add(buildArg);
            } else {
                result.addAll(Arrays.asList(buildArg.split("\\s+", 2)));
            }
        }
        return result;
    }

    protected Path processSupportedArtifacts(Artifact artifact) throws MojoExecutionException {
        return processArtifact(artifact, "jar", "test-jar", "war");
    }

    protected Path processArtifact(Artifact artifact, String... artifactTypes) throws MojoExecutionException {
        File artifactFile = artifact.getFile();

        if (artifactFile == null) {
            logger.debug("Missing artifact file for artifact " + artifact + " (type: " + artifact.getType() + ")");
            return resolveClassesDirectoryFromReactor(artifact).filter(Files::exists).orElse(null);
        }

        if (Arrays.stream(artifactTypes).noneMatch(a -> a.equals(artifact.getType()))) {
            logger.warn("Ignoring ImageClasspath Entry '" + artifact + "' with unsupported type '" + artifact.getType() + "'");
            return null;
        }

        if (!artifactFile.exists()) {
            Optional<Path> reactorOutput = resolveClassesDirectoryFromReactor(artifact);
            if (reactorOutput.isPresent()) {
                Path reactorPath = reactorOutput.get();
                if (Files.exists(reactorPath)) {
                    logger.debug("ImageClasspath Entry: " + artifact + " (" + reactorPath.toUri() + ")");
                    return reactorPath;
                } else {
                    logger.debug("Skipping artifact " + artifact + " because no packaged file or classes directory was found.");
                    return null;
                }
            }
        }

        Path jarFilePath = artifactFile.toPath();
        logger.debug("ImageClasspath Entry: " + artifact + " (" + jarFilePath.toUri() + ")");

        warnIfWrongMetaInfLayout(jarFilePath, artifact);
        return jarFilePath;
    }

    /**
     * Resolves the physical output directory (classes or test-classes) for a given artifact
     * by searching the current Maven reactor.
     * <p>
     * This is used as a fallback when an artifact's JAR file has not yet been created,
     * allowing the plugin to use compiled class folders instead.
     *
     * @param artifact The dependency artifact to resolve within the reactor.
     * @return An Optional containing the {@link Path} to the output directory if found,
     * otherwise an empty Optional.
     */
    private Optional<Path> resolveClassesDirectoryFromReactor(Artifact artifact) {
        return Optional.ofNullable(session)
            .flatMap(s -> s.getAllProjects().stream()
                .filter(project -> Objects.equals(project.getGroupId(), artifact.getGroupId())
                        && Objects.equals(project.getArtifactId(), artifact.getArtifactId())
                        && Objects.equals(project.getVersion(), artifact.getVersion()))
                .map(MavenProject::getBuild)
                .map(build -> "test-jar".equals(artifact.getType()) ? build.getTestOutputDirectory() : build.getOutputDirectory())
                .filter(dir -> dir != null && !dir.isEmpty())
                .map(Paths::get)
                .findFirst());
    }

    protected void addArtifactToClasspath(Artifact artifact) throws MojoExecutionException {
        if (!isExcluded(artifact)) {
            Optional.ofNullable(processSupportedArtifacts(artifact)).ifPresent(imageClasspath::add);
        }
    }

    private static FileSystem openFileSystem(URI uri) throws IOException {
      FileSystem fs;
      try {
        fs = FileSystems.newFileSystem(uri, Collections.emptyMap());
      } catch (FileSystemAlreadyExistsException e) {
        fs = FileSystems.getFileSystem(uri);
      }
      return fs;
    }

    protected void warnIfWrongMetaInfLayout(Path jarFilePath, Artifact artifact) throws MojoExecutionException {
        if (jarFilePath.toFile().isDirectory()) {
            logger.debug("Artifact `" + jarFilePath + "` is a directory.");
            return;
        }
        URI jarFileURI = URI.create("jar:" + jarFilePath.toUri());
        try (FileSystem jarFS = openFileSystem(jarFileURI)) {
            Path nativeImageMetaInfBase = jarFS.getPath("/" + NATIVE_IMAGE_META_INF);
            if (Files.isDirectory(nativeImageMetaInfBase)) {
                try (Stream<Path> stream = Files.walk(nativeImageMetaInfBase)) {
                    List<Path> nativeImageProperties = stream
                            .filter(p -> p.endsWith(NATIVE_IMAGE_PROPERTIES_FILENAME)).collect(Collectors.toList());
                    for (Path nativeImageProperty : nativeImageProperties) {
                        Path relativeSubDir = nativeImageMetaInfBase.relativize(nativeImageProperty).getParent();
                        boolean valid = relativeSubDir != null && (relativeSubDir.getNameCount() == 2);
                        valid = valid && relativeSubDir.getName(0).toString().equals(artifact.getGroupId());
                        valid = valid && relativeSubDir.getName(1).toString().equals(artifact.getArtifactId());
                        if (!valid) {
                            String example = NATIVE_IMAGE_META_INF + "/%s/%s/" + NATIVE_IMAGE_PROPERTIES_FILENAME;
                            example = String.format(example, artifact.getGroupId(), artifact.getArtifactId());
                            logger.warn("Properties file at '" + nativeImageProperty.toUri() + "' does not match the recommended '" + example + "' layout.");
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new MojoExecutionException("Artifact " + artifact + "cannot be added to image classpath", e);
        }
    }

    protected abstract List<String> getDependencyScopes();

    protected void addDependenciesToClasspath() throws MojoExecutionException {
        configureMetadataRepository();
        Set<Artifact> collected = new HashSet<>();
        // Resolve repository metadata after collecting the complete eligible dependency graph.
        // §common/FS-common-libraries.5.1 §FS-resources-and-metadata.2.
        List<Artifact> metadataDependencies = new ArrayList<>();
        // Must keep classpath order is the same with surefire test
        for (Artifact dependency : project.getArtifacts()) {
            if (!"nil".equals(dependency.getType())
                    && getDependencyScopes().contains(dependency.getScope())
                    && collected.add(dependency)
                    && !isExcluded(dependency)) {
                Path dependencyPath = processSupportedArtifacts(dependency);
                if (dependencyPath != null) {
                    imageClasspath.add(dependencyPath);
                    if (dependency.getFile() != null) {
                        metadataDependencies.add(dependency);
                    }
                }
            }
        }
        addDependencyMetadata(metadataDependencies, file -> {
            buildArgs.add("--exclude-config");
            buildArgs.add(Pattern.quote(file.getAbsolutePath()));
            buildArgs.add("^/META-INF/native-image/");
        });
    }

    private List<String> resolveLayerUseArguments() throws MojoExecutionException {
        List<Artifact> artifacts = resolveLayerUseArtifacts();
        resolveLayerRuntimeDirectories(artifacts);
        return artifacts.stream()
            .map(Artifact::getFile)
            .map(File::toPath)
            .map(NativeImageLayerArguments::renderLayerUse)
            .toList();
    }

    /**
     * Directories that contain layer libraries consumed by this image. §FS-native-builds.3.
     */
    protected List<Path> getUsedLayerLibraryDirectories() throws MojoExecutionException {
        return resolveLayerRuntimeDirectories(resolveLayerUseArtifacts());
    }

    private List<Artifact> resolveLayerUseArtifacts() throws MojoExecutionException {
        if (resolvedLayerUseArtifacts != null) {
            return resolvedLayerUseArtifacts;
        }
        List<Artifact> nilArtifacts = project.getArtifacts().stream()
            .filter(artifact -> "nil".equals(artifact.getType()))
            .toList();
        if (useLayers == null || useLayers.isEmpty()) {
            warnAboutUnreferencedLayers(nilArtifacts);
            resolvedLayerUseArtifacts = List.of();
            return resolvedLayerUseArtifacts;
        }
        Set<String> selected = new HashSet<>();
        Set<Artifact> selectedArtifacts = new LinkedHashSet<>();
        for (UseLayerConfiguration useLayer : useLayers) {
            String selector = useLayer.getArtifact();
            if (selector == null || selector.isBlank()) {
                throw new MojoExecutionException("useLayers entries require non-blank artifact coordinates");
            }
            if (!selected.add(selector)) {
                throw new MojoExecutionException("Layer dependency '" + selector + "' is selected more than once");
            }
            String[] coordinate = parseLayerCoordinate(selector);
            List<Artifact> matches = nilArtifacts.stream()
                .filter(artifact -> matchesLayerCoordinate(artifact, coordinate))
                .toList();
            if (matches.isEmpty()) {
                throw new MojoExecutionException(
                    "Layer dependency '" + selector + "' was not found. Declare the corresponding "
                        + "<dependency> with <type>nil</type> in the project.");
            }
            if (matches.size() > 1) {
                throw new MojoExecutionException("Layer dependency '" + selector + "' is ambiguous: " + matches);
            }
            if (!selectedArtifacts.add(matches.get(0))) {
                throw new MojoExecutionException(
                    "Layer dependency '" + selector + "' selects an artifact that is already selected");
            }
            if (matches.get(0).getFile() == null) {
                throw new MojoExecutionException("Layer dependency '" + selector + "' has no resolved file");
            }
        }
        warnAboutUnreferencedLayers(nilArtifacts.stream()
            .filter(artifact -> !selectedArtifacts.contains(artifact))
            .toList());
        resolvedLayerUseArtifacts = List.copyOf(selectedArtifacts);
        return resolvedLayerUseArtifacts;
    }

    private List<Path> resolveLayerRuntimeDirectories(List<Artifact> layerArtifacts) throws MojoExecutionException {
        if (resolvedLayerRuntimeDirectories != null) {
            return resolvedLayerRuntimeDirectories;
        }
        if (layerArtifacts.isEmpty()) {
            resolvedLayerRuntimeDirectories = List.of();
            return resolvedLayerRuntimeDirectories;
        }
        String classifier = NativeImageLayerRuntime.classifier(buildArgs);
        List<Path> directories = new ArrayList<>();
        for (Artifact layerArtifact : layerArtifacts) {
            org.eclipse.aether.artifact.Artifact runtimeArtifact = new DefaultArtifact(
                layerArtifact.getGroupId(),
                layerArtifact.getArtifactId(),
                classifier,
                NativeImageLayerRuntime.ARCHIVE_TYPE,
                layerArtifact.getVersion());
            ArtifactRequest request = new ArtifactRequest(runtimeArtifact, project.getRemoteProjectRepositories(), null);
            Path archive = resolveLayerRuntimeArchive(layerArtifact, runtimeArtifact, request);
            Path destination = Path.of(project.getBuild().getDirectory(), "native", "layer-runtime",
                layerArtifact.getGroupId(), layerArtifact.getArtifactId(), layerArtifact.getVersion(), classifier);
            try {
                NativeImageLayerRuntime.extractArchive(archive, destination, logger::warn);
            } catch (IOException ex) {
                throw new MojoExecutionException("Unable to stage layer runtime archive " + runtimeArtifact
                    + " in " + destination, ex);
            }
            directories.add(destination);
        }
        resolvedLayerRuntimeDirectories = List.copyOf(directories);
        return resolvedLayerRuntimeDirectories;
    }

    protected Path resolveLayerRuntimeArchive(Artifact layerArtifact,
                                              org.eclipse.aether.artifact.Artifact runtimeArtifact,
                                              ArtifactRequest request) throws MojoExecutionException {
        try {
            return repositorySystem.resolveArtifact(mavenSession.getRepositorySession(), request)
                .getArtifact().getFile().toPath();
        } catch (ArtifactResolutionException ex) {
            throw new MojoExecutionException("Layer '" + layerArtifact.getGroupId() + ":"
                + layerArtifact.getArtifactId() + ":" + layerArtifact.getVersion()
                + "' is missing its deployable runtime companion " + runtimeArtifact
                + ". A .nil artifact alone is not deployable; republish the layer with a Native Build Tools "
                + "version that attaches runtime bundles.", ex);
        }
    }

    private void warnAboutUnreferencedLayers(List<Artifact> artifacts) {
        for (Artifact artifact : artifacts) {
            logger.warn("Layer dependency '" + artifact.getGroupId() + ":" + artifact.getArtifactId()
                + "' has type nil but is not referenced by useLayers; it will not be consumed.");
        }
    }

    static String[] parseLayerCoordinate(String selector) throws MojoExecutionException {
        String[] parts = selector.split(":", -1);
        if (parts.length < 2 || parts.length > 3
                || Arrays.stream(parts).anyMatch(String::isBlank)) {
            throw new MojoExecutionException(
                "Layer dependency must use groupId:artifactId[:version]: " + selector);
        }
        return parts;
    }

    private static boolean matchesLayerCoordinate(Artifact artifact, String[] parts) {
        return artifact.getGroupId().equals(parts[0])
            && artifact.getArtifactId().equals(parts[1])
            && (parts.length == 2 || artifact.getVersion().equals(parts[2]));
    }

    protected void addInferredDependenciesToClasspath() {

    }

    @Override
    protected void maybeAddDependencyMetadata(Artifact dependency, Consumer<File> excludeAction) {
        if (isExcluded(dependency)) {
            return;
        }
        super.maybeAddDependencyMetadata(dependency, excludeAction);
    }

    protected boolean isExcluded(Artifact dependency) {
        if (exclusions == null) {
            return false;
        }
        return exclusions.stream()
            .anyMatch(e -> e.getGroupId().equals(dependency.getGroupId()) && e.getArtifactId().equals(dependency.getArtifactId()));
    }

    /**
     * Returns path to where application classes are stored, or jar artifact if it is produced.
     * @return Path to application classes
     * @throws MojoExecutionException failed getting main build path
     */
    protected Path getMainBuildPath() throws MojoExecutionException {
        if (classesDirectory != null) {
            return classesDirectory.toPath();
        } else {
            Path artifactPath = processArtifact(project.getArtifact(), project.getPackaging());
            if (artifactPath != null) {
                return artifactPath;
            } else {
                return defaultClassesDirectory.toPath();
            }
        }
    }

    protected void populateApplicationClasspath() throws MojoExecutionException {
        imageClasspath.add(getMainBuildPath());
    }

    protected void populateClasspath() throws MojoExecutionException {
        if (classpath != null && !classpath.isEmpty()) {
            imageClasspath.addAll(classpath.stream()
                    .map(Paths::get)
                    .map(Path::toAbsolutePath)
                    .collect(Collectors.toSet())
            );
        } else {
            populateApplicationClasspath();
            addDependenciesToClasspath();
        }
        addInferredDependenciesToClasspath();
        maybeAddDynamicAccessMetadataToClasspath();
        imageClasspath.removeIf(entry -> !entry.toFile().exists());
    }

    protected String getClasspath() throws MojoExecutionException {
        if (imageClasspath.isEmpty()) {
            populateClasspath();
        }
        if (imageClasspath.isEmpty()) {
            if (isLayerCreateBuild()) {
                return "";
            }
            throw new MojoExecutionException("Image classpath is empty. " +
                    "Check if your classpath configuration is correct.");
        }
        return imageClasspath.stream()
                .map(Path::toString)
                .collect(Collectors.joining(File.pathSeparator));
    }

    private boolean isLayerCreateBuild() {
        return buildArgs != null && buildArgs.stream()
                .filter(Objects::nonNull)
                .anyMatch(arg -> LAYER_CREATE_ARG.matcher(arg.trim()).matches());
    }

    protected void buildImage() throws MojoExecutionException {
        checkRequiredVersionIfNeeded();
        Path nativeImageExecutable = NativeImageConfigurationUtils.getNativeImageSupportingToolchain(logger, toolchainManager, session, enforceToolchain);
        warnAboutUnsupportedLayerConsumption(nativeImageExecutable);
        if (isMetadataRepositoryEnabled() && metadataRepository != null) {
            SchemaValidationUtils.validateReachabilityMetadataSchema(((FileSystemRepository) metadataRepository).getRootDirectory(), NativeImageUtils.getMajorJDKVersion(getVersionInformation(null)), nativeImageExecutable);
        }
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(nativeImageExecutable.toString());
            processBuilder.command().addAll(getBuildArgs());

            if (environment != null) {
                processBuilder.environment().putAll(environment);
            }

            if (!outputDirectory.exists() && !outputDirectory.mkdirs()) {
                throw new MojoExecutionException("Failed creating output directory");
            }
            processBuilder.inheritIO();

            String commandString = String.join(" ", processBuilder.command());
            logger.info("Executing: " + commandString);

            if (dryRun) {
                logger.warn("Skipped native-image building due to `" + NATIVE_IMAGE_DRY_RUN + "` being specified.");
                return;
            }

            Process imageBuildProcess = processBuilder.start();
            if (imageBuildProcess.waitFor() != 0) {
                throw new MojoExecutionException("Execution of " + commandString + " returned non-zero result");
            }
        } catch (IOException | InterruptedException e) {
            throw new MojoExecutionException("Building image with " + nativeImageExecutable + " failed", e);
        }
    }

    private void warnAboutUnsupportedLayerConsumption(Path nativeImageExecutable) throws MojoExecutionException {
        if (useLayers == null || useLayers.isEmpty()) {
            return;
        }
        String versionInformation = getVersionInformation(logger, nativeImageExecutable);
        if (NativeImageUtils.shouldWarnAboutUnsupportedLayerConsumption(versionInformation, true)) {
            logger.warn("Layer consumption is supported on GraalVM 25.1 and later. Continuing on "
                + "GraalVM 25.0.x is unsupported and at your own risk.");
        }
    }

    protected void checkRequiredVersionIfNeeded() throws MojoExecutionException {
        if (requiredVersion == null) {
            return;
        }
        NativeImageUtils.checkVersion(requiredVersion, getVersionInformation(logger));
    }

    protected static boolean isOracleGraalVM(Logger logger) throws MojoExecutionException {
        return getVersionInformation(logger).contains(ORACLE_GRAALVM_IDENTIFIER);
    }

    /**
     * Returns the output of calling "native-image --version".
     * @param logger a logger, that may be null, to print warnings or useful information.
     * @return the output as a string joined by "\n".
     * @throws MojoExecutionException when any errors occurred.
     */
    protected static String getVersionInformation(Logger logger) throws MojoExecutionException {
        if (nativeImageVersionInformation != null) {
            return nativeImageVersionInformation;
        }

        return getVersionInformation(logger, NativeImageConfigurationUtils.getNativeImage(logger));
    }

    private static String getVersionInformation(Logger logger, Path nativeImageExecutable) throws MojoExecutionException {
        if (nativeImageVersionInformation != null) {
            return nativeImageVersionInformation;
        }

        try {
            ProcessBuilder processBuilder = new ProcessBuilder(nativeImageExecutable.toString());
            processBuilder.command().add("--version");
            Process versionCheckProcess = processBuilder.start();
            if (versionCheckProcess.waitFor() != 0) {
                String commandString = String.join(" ", processBuilder.command());
                throw new MojoExecutionException("Execution of " + commandString + " returned non-zero result");
            }
            InputStream inputStream = versionCheckProcess.getInputStream();
            nativeImageVersionInformation = new BufferedReader(
                    new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining("\n"));
            return nativeImageVersionInformation;
        } catch (IOException | InterruptedException e) {
            throw new MojoExecutionException("Checking GraalVM version with " + nativeImageExecutable + " failed", e);
        }
    }

    protected void maybeAddGeneratedResourcesConfig(List<String> into) {
        if (resourcesConfigDirectory.exists() || agentResourceDirectory != null) {
            File[] dirs = resourcesConfigDirectory.listFiles();
            Stream<File> configDirs =
                    Stream.concat(dirs == null ? Stream.empty() : Arrays.stream(dirs),
                            agentResourceDirectory == null ? Stream.empty() : Stream.of(agentResourceDirectory).filter(File::isDirectory));

            String value = configDirs.map(File::getAbsolutePath).collect(Collectors.joining(","));
            if (!value.isEmpty()) {
                into.add("-H:ConfigurationFileDirectories=" + value);
            }
        }
    }

    protected void maybeAddDynamicAccessMetadataToClasspath() {
        if (Files.exists(Path.of(outputDirectory.getPath(), "dynamic-access-metadata.json"))) {
            imageClasspath.add(Path.of(outputDirectory.getPath(), "dynamic-access-metadata.json"));
        }
    }

    protected void maybeAddReachabilityMetadata(List<String> configDirs) {
        if (isMetadataRepositoryEnabled() && !metadataRepositoryConfigurations.isEmpty()) {
            metadataRepositoryConfigurations.stream()
                    .map(configuration -> configuration.getDirectory().toAbsolutePath())
                    .map(Path::toFile)
                    .map(File::getAbsolutePath)
                    .forEach(configDirs::add);
        }
    }
}
