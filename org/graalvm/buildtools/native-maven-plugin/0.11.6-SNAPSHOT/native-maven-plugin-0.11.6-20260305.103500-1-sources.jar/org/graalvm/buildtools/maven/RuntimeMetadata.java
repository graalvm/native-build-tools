package org.graalvm.buildtools.maven;

public abstract class RuntimeMetadata {
    private RuntimeMetadata() { }

   public static final String GROUP_ID = "org.graalvm.buildtools";
   public static final String VERSION = "0.11.6-SNAPSHOT";
   public static final String JUNIT_PLATFORM_NATIVE_ARTIFACT_ID = "junit-platform-native";

}
